# SSL Certificate & HTTPS Deployment Guide

## Current Status

✅ **Application Build:** Ready for deployment
✅ **Security Headers:** HSTS configured in `netlify.toml`
✅ **Redirects:** SPA routing configured
✅ **SSL-Ready:** All configuration files in place

## Domain Information

**Primary Domain:** reflectionsbarber.shop
**WWW Domain:** www.reflectionsbarber.shop
**SSL Provider:** Let's Encrypt (free, automatic)
**Certificate Renewal:** Automatic every 60 days

## Files Created

### 1. `netlify.toml` (Root Directory)
- Build configuration
- **HSTS headers** for forced HTTPS
- Security headers (XSS, frame options, CSP)
- Cache headers for assets
- SPA redirect rules

### 2. `public/_redirects`
- Single Page Application routing
- Ensures all routes go to index.html

### 3. `dist/_redirects` (Auto-generated)
- Copied from public during build
- Deployed with the application

## Manual Steps Required - SSL Certificate Issuance

### Option A: Netlify Deployment

If deploying to Netlify:

#### Step 1: Deploy to Netlify
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Deploy
netlify deploy --prod
```

#### Step 2: Configure Custom Domain
1. Go to: https://app.netlify.com/sites/[your-site]/settings/domain
2. Click "Add custom domain"
3. Enter: `reflectionsbarber.shop`
4. Click "Verify"
5. Follow DNS configuration instructions

#### Step 3: Configure DNS (Your Domain Registrar)

Add these DNS records at your domain registrar:

**For Apex Domain (reflectionsbarber.shop):**
```
Type: A
Name: @
Value: 75.2.60.5 (Netlify's load balancer IP)
TTL: 3600
```

**OR use ALIAS/ANAME record:**
```
Type: ALIAS or ANAME
Name: @
Value: [your-site].netlify.app
TTL: 3600
```

**For WWW subdomain:**
```
Type: CNAME
Name: www
Value: [your-site].netlify.app
TTL: 3600
```

#### Step 4: Enable SSL (Automatic)
1. Once DNS propagates (5-30 minutes)
2. Go to: Domain Settings → HTTPS
3. Netlify automatically provisions Let's Encrypt certificate
4. Wait for green checkmark: "SSL certificate provisioned"
5. Enable "Force HTTPS" toggle

#### Step 5: Verify HSTS Headers
```bash
curl -I https://reflectionsbarber.shop

# Should see:
# strict-transport-security: max-age=63072000; includeSubDomains; preload
```

### Option B: Vercel Deployment

If deploying to Vercel:

#### Step 1: Deploy to Vercel
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

#### Step 2: Configure Custom Domain
1. Go to: https://vercel.com/[your-username]/[project]/settings/domains
2. Click "Add"
3. Enter: `reflectionsbarber.shop`
4. Click "Add"

#### Step 3: Configure DNS
Follow Vercel's instructions to add:

**For Apex Domain:**
```
Type: A
Name: @
Value: 76.76.21.21 (Vercel's IP)
```

**For WWW:**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

#### Step 4: SSL Auto-Provisioning
- Vercel automatically provisions Let's Encrypt certificate
- Usually takes 1-5 minutes after DNS propagation
- Green checkmark appears when ready
- HTTPS forced by default

### Option C: Manual Deployment (Any Host)

#### Step 1: Upload Build Files
```bash
# Build the project
npm run build

# Upload contents of 'dist' folder to your web host
# Include: index.html, assets/, _redirects
```

#### Step 2: Configure Web Server

**For Nginx:**
```nginx
server {
    listen 80;
    server_name reflectionsbarber.shop www.reflectionsbarber.shop;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name reflectionsbarber.shop www.reflectionsbarber.shop;

    # SSL Certificate paths (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/reflectionsbarber.shop/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/reflectionsbarber.shop/privkey.pem;

    # HSTS Header
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;

    # Security Headers
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    root /var/www/reflectionsbarber.shop/dist;
    index index.html;

    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

#### Step 3: Install Let's Encrypt Certificate
```bash
# Install Certbot
sudo apt-get update
sudo apt-get install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d reflectionsbarber.shop -d www.reflectionsbarber.shop

# Certificate auto-renews every 60 days
```

## Security Headers Included

All deployed via `netlify.toml`:

### HSTS (HTTP Strict Transport Security)
```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
```
- Forces HTTPS for 2 years
- Applies to all subdomains
- Eligible for browser preload list

### Content Security Policy
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval';
  style-src 'self' 'unsafe-inline'; img-src 'self' data: https: blob:;
  connect-src 'self' https://*.supabase.co wss://*.supabase.co https://images.pexels.com
```
- Restricts resource loading
- Allows Supabase API calls
- Permits Pexels images

### Other Security Headers
- `X-Frame-Options: DENY` - Prevents clickjacking
- `X-Content-Type-Options: nosniff` - Prevents MIME sniffing
- `X-XSS-Protection: 1; mode=block` - XSS filter
- `Referrer-Policy: strict-origin-when-cross-origin` - Privacy
- `Permissions-Policy` - Blocks geolocation, camera, microphone

## Verification Steps

### 1. Check SSL Certificate
```bash
# Check certificate validity
openssl s_client -connect reflectionsbarber.shop:443 -servername reflectionsbarber.shop

# Should show:
# - Issuer: Let's Encrypt
# - Valid from: [date]
# - Valid to: [date + 90 days]
```

### 2. Test HTTPS Redirect
```bash
# HTTP should redirect to HTTPS
curl -I http://reflectionsbarber.shop

# Should return:
# HTTP/1.1 301 Moved Permanently
# Location: https://reflectionsbarber.shop/
```

### 3. Verify Security Headers
```bash
# Check HSTS header
curl -I https://reflectionsbarber.shop | grep -i strict-transport

# Should return:
# strict-transport-security: max-age=63072000; includeSubDomains; preload
```

### 4. Test WWW Redirect
```bash
# WWW should work
curl -I https://www.reflectionsbarber.shop

# Should return 200 OK or redirect to apex domain
```

### 5. SSL Labs Test
Visit: https://www.ssllabs.com/ssltest/analyze.html?d=reflectionsbarber.shop

**Target Grade:** A+ (with HSTS)

### 6. Security Headers Test
Visit: https://securityheaders.com/?q=reflectionsbarber.shop

**Target Grade:** A (with all headers)

## Troubleshooting

### Issue: SSL Certificate Not Issuing

**Possible Causes:**
1. DNS not propagated (wait 5-30 minutes)
2. Domain verification failed
3. CAA records blocking Let's Encrypt

**Solutions:**
```bash
# Check DNS propagation
dig reflectionsbarber.shop
dig www.reflectionsbarber.shop

# Check CAA records (should allow letsencrypt.org)
dig CAA reflectionsbarber.shop

# If CAA exists, ensure it includes:
# 0 issue "letsencrypt.org"
```

### Issue: HSTS Not Working

**Check:**
1. Verify `netlify.toml` is in root directory
2. Ensure deployed to production (not preview)
3. Clear browser cache and test in incognito

### Issue: Mixed Content Warnings

**Solution:**
- Update all HTTP resources to HTTPS
- Check: Images, scripts, stylesheets, fonts
- Supabase URLs should already be HTTPS

### Issue: SPA Routes 404

**Check:**
1. `_redirects` file in `dist/` folder
2. Contents: `/*    /index.html   200`
3. Rebuild if missing

## HSTS Preload (Optional)

Once SSL is stable for 30+ days, submit for browser preload:

1. Visit: https://hstspreload.org/
2. Enter: `reflectionsbarber.shop`
3. Click "Check HSTS preload status"
4. If eligible, click "Submit"

**Benefits:**
- Browser enforces HTTPS before first visit
- Maximum security
- Improved user trust

**Requirements:**
- Valid certificate
- HSTS header with `preload` directive
- max-age ≥ 31536000 (1 year)
- includeSubDomains directive
- HTTPS on base domain and all subdomains

## Quick Deployment Checklist

- [ ] Build project: `npm run build`
- [ ] Deploy to hosting (Netlify/Vercel/Custom)
- [ ] Configure custom domain in host dashboard
- [ ] Add DNS records (A/ALIAS + CNAME)
- [ ] Wait for DNS propagation (5-30 min)
- [ ] Verify SSL certificate issued (green check)
- [ ] Test HTTPS redirect (http → https)
- [ ] Verify HSTS header present
- [ ] Test all security headers
- [ ] Test WWW and apex domain
- [ ] Test SPA routing (refresh on route)
- [ ] Test SSL Labs (target: A+)
- [ ] Test Security Headers (target: A)
- [ ] (Optional) Submit to HSTS preload

## Support

### Netlify SSL Issues
- Docs: https://docs.netlify.com/domains-https/https-ssl/
- Support: https://answers.netlify.com/

### Let's Encrypt Issues
- Community: https://community.letsencrypt.org/
- Status: https://letsencrypt.status.io/

### DNS Propagation
- Check: https://www.whatsmydns.net/
- Tool: https://dnschecker.org/

## Summary

**Files Ready:**
✅ `netlify.toml` - HSTS + security headers configured
✅ `public/_redirects` - SPA routing configured
✅ `dist/_redirects` - Deployed with build
✅ Application built and ready

**Next Action:**
1. Choose deployment platform (Netlify recommended)
2. Deploy using CLI or dashboard
3. Configure custom domain
4. Add DNS records
5. Wait for automatic SSL provisioning (1-30 min)
6. Verify green checkmark in domain settings
7. Test HTTPS and HSTS headers

**SSL certificate will be issued automatically by Let's Encrypt once DNS is configured!**
