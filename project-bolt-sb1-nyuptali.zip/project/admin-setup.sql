-- Reflections Barbershop - Admin Setup Script
-- Run these queries in Supabase SQL Editor after signing up

-- 1. Set your account as admin (replace with your email)
UPDATE profiles
SET role = 'admin'
WHERE email = 'your-email@example.com';

-- 2. View all barbers with their IDs (for CSV import)
SELECT id, display_name, is_active FROM barbers ORDER BY display_name;

-- 3. View all services with their IDs (for CSV import)
SELECT id, name, price, duration_minutes FROM services WHERE is_active = true;

-- 4. Create a barber account and link to existing barber
-- First, user signs up normally, then run:
UPDATE profiles SET role = 'barber' WHERE email = 'barber-email@example.com';

-- Then link to barber profile:
UPDATE barbers
SET user_id = (SELECT id FROM profiles WHERE email = 'barber-email@example.com')
WHERE display_name = 'Mario';

-- 5. View recent bookings
SELECT
  b.booking_date,
  b.start_time,
  b.client_name,
  br.display_name as barber,
  s.name as service,
  b.status
FROM bookings b
JOIN barbers br ON b.barber_id = br.id
JOIN services s ON b.service_id = s.id
ORDER BY b.booking_date DESC, b.start_time DESC
LIMIT 20;

-- 6. Get booking statistics
SELECT
  COUNT(*) as total_bookings,
  SUM(CASE WHEN booking_date = CURRENT_DATE THEN 1 ELSE 0 END) as today_bookings,
  COUNT(DISTINCT barber_id) as active_barbers
FROM bookings;

-- 7. Revenue report
SELECT
  b.booking_date,
  br.display_name as barber,
  COUNT(*) as appointments,
  SUM(s.price) as revenue
FROM bookings b
JOIN barbers br ON b.barber_id = br.id
JOIN services s ON b.service_id = s.id
WHERE b.status IN ('confirmed', 'completed')
GROUP BY b.booking_date, br.display_name
ORDER BY b.booking_date DESC;

-- 8. Add more barbers (if needed)
INSERT INTO barbers (display_name, bio, is_active) VALUES
  ('Tony', 'Precision cuts specialist', true),
  ('Luis', 'Expert in fades and tapers', true),
  ('Andre', 'Modern styling expert', true);

-- 9. Update barber working hours
UPDATE barbers
SET start_time = '10:00:00', end_time = '20:00:00'
WHERE display_name = 'Mario';

-- 10. Set barber days off (e.g., Sunday and Monday)
UPDATE barbers
SET days_off = ARRAY['sunday', 'monday']
WHERE display_name = 'Mario';
