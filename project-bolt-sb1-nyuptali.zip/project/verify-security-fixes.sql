-- Verification Script for Security and Performance Fixes
-- Run this in Supabase SQL Editor to verify all fixes are applied

-- =====================================================
-- 1. VERIFY FOREIGN KEY INDEXES
-- =====================================================

SELECT
    '✓ Foreign Key Indexes' as check_name,
    COUNT(*) as found,
    CASE
        WHEN COUNT(*) = 2 THEN '✓ PASS'
        ELSE '✗ FAIL - Expected 2 indexes'
    END as status
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname IN ('idx_barbers_user_id', 'idx_bookings_service_id');

-- Show the indexes
SELECT
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname IN ('idx_barbers_user_id', 'idx_bookings_service_id')
ORDER BY tablename;

-- =====================================================
-- 2. VERIFY FUNCTION SEARCH PATHS
-- =====================================================

SELECT
    '✓ Function Security' as check_name,
    COUNT(*) as found,
    CASE
        WHEN COUNT(*) = 2 THEN '✓ PASS'
        ELSE '✗ FAIL - Expected 2 secure functions'
    END as status
FROM pg_proc
WHERE proname IN ('handle_new_user', 'update_updated_at_column')
AND prosecdef = true
AND 'search_path=public' = ANY(proconfig);

-- Show function details
SELECT
    proname as function_name,
    prosecdef as security_definer,
    proconfig as config
FROM pg_proc
WHERE proname IN ('handle_new_user', 'update_updated_at_column');

-- =====================================================
-- 3. VERIFY POLICY CONSOLIDATION
-- =====================================================

SELECT
    '✓ Policy Count' as check_name,
    tablename,
    COUNT(*) as policy_count,
    CASE
        WHEN tablename = 'profiles' AND COUNT(*) = 3 THEN '✓ PASS (3 policies)'
        WHEN tablename = 'barbers' AND COUNT(*) = 4 THEN '✓ PASS (4 policies)'
        WHEN tablename = 'services' AND COUNT(*) = 2 THEN '✓ PASS (2 policies)'
        WHEN tablename = 'bookings' AND COUNT(*) = 4 THEN '✓ PASS (4 policies)'
        WHEN tablename = 'barber_availability_exceptions' AND COUNT(*) = 2 THEN '✓ PASS (2 policies)'
        ELSE '⚠ Review policy count'
    END as status
FROM pg_policies
WHERE schemaname = 'public'
GROUP BY tablename
ORDER BY tablename;

-- =====================================================
-- 4. VERIFY NO OVERLAPPING PERMISSIVE POLICIES
-- =====================================================

SELECT
    '✓ No Policy Overlap' as check_name,
    tablename,
    cmd as action,
    COUNT(*) as policy_count,
    CASE
        WHEN COUNT(*) > 1 THEN '⚠ Multiple policies (by design for some cases)'
        ELSE '✓ PASS'
    END as status
FROM pg_policies
WHERE schemaname = 'public'
AND permissive = 'PERMISSIVE'
GROUP BY tablename, cmd, roles
HAVING COUNT(*) > 1
ORDER BY tablename, cmd;

-- If this returns no rows or expected duplicates, policies are consolidated

-- =====================================================
-- 5. VERIFY RLS POLICY OPTIMIZATION
-- =====================================================

-- Check for auth.uid() without select wrapper (should find none)
SELECT
    '✓ Optimized auth.uid()' as check_name,
    COUNT(*) as policies_with_direct_auth_uid,
    CASE
        WHEN COUNT(*) = 0 THEN '✓ PASS - All policies optimized'
        ELSE '⚠ Some policies may need optimization'
    END as status
FROM pg_policies
WHERE schemaname = 'public'
AND (qual::text LIKE '%auth.uid()%' OR with_check::text LIKE '%auth.uid()%')
AND NOT (qual::text LIKE '%(select auth.uid())%' OR with_check::text LIKE '%(select auth.uid())%');

-- =====================================================
-- 6. VERIFY ALL INDEXES EXIST
-- =====================================================

SELECT
    '✓ All Required Indexes' as check_name,
    COUNT(*) as index_count,
    CASE
        WHEN COUNT(*) >= 8 THEN '✓ PASS'
        ELSE '✗ FAIL - Missing indexes'
    END as status
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname LIKE 'idx_%';

-- List all custom indexes
SELECT
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname LIKE 'idx_%'
ORDER BY tablename, indexname;

-- =====================================================
-- 7. VERIFY RLS IS ENABLED
-- =====================================================

SELECT
    '✓ RLS Enabled' as check_name,
    tablename,
    CASE
        WHEN rowsecurity THEN '✓ PASS'
        ELSE '✗ FAIL - RLS not enabled'
    END as status
FROM pg_tables
WHERE schemaname = 'public'
AND tablename IN ('profiles', 'barbers', 'services', 'bookings', 'barber_availability_exceptions');

-- =====================================================
-- 8. COMPREHENSIVE SUMMARY
-- =====================================================

SELECT '
╔════════════════════════════════════════════════════╗
║   SECURITY & PERFORMANCE VERIFICATION SUMMARY      ║
╚════════════════════════════════════════════════════╝

Run all queries above to verify:

1. ✓ Foreign key indexes created
2. ✓ Function search paths secured
3. ✓ Policies consolidated
4. ✓ No overlapping permissive policies (except by design)
5. ✓ RLS policies optimized with (select auth.uid())
6. ✓ All required indexes present
7. ✓ RLS enabled on all tables

MANUAL STEP REQUIRED:
⚠️  Enable "Leaked Password Protection" in Supabase Dashboard
    Authentication > Providers > Email > Security Settings

If all checks pass ✓, security fixes are successfully applied!
' as summary;

-- =====================================================
-- 9. PERFORMANCE TEST QUERY
-- =====================================================

-- Test optimized query performance (example)
EXPLAIN ANALYZE
SELECT b.*, br.display_name, s.name, s.price
FROM bookings b
JOIN barbers br ON b.barber_id = br.id
JOIN services s ON b.service_id = s.id
WHERE b.booking_date = CURRENT_DATE
AND b.status IN ('confirmed', 'pending');

-- This should show Index Scans instead of Seq Scans on joins