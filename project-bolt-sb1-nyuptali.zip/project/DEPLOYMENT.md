# Reflections Barbershop - Deployment Guide

## Quick Start

Your barbershop booking system is ready to deploy! The build has been tested and is working perfectly.

## What's Been Built

### Frontend Application
- Landing page with services showcase
- Interactive booking calendar with real-time availability
- Barber dashboard for managing appointments
- Admin dashboard for complete system management
- Client portal for appointment history
- Mobile-responsive design with modern barber shop aesthetic

### Database & Backend
- Complete Supabase database schema
- 5 pre-loaded services (Fade, Lineup, Beard Trim, Full Service, Kids Cut)
- 5 sample barbers (ready to customize)
- Row-level security policies
- RESTful API endpoints via Edge Functions
- Authentication system with role-based access

### Key Features
- Real-time booking calendar
- Automatic conflict prevention
- Guest and registered client bookings
- CSV import for Squire data migration
- Revenue tracking and reporting
- Barber schedule management
- SMS notification infrastructure (ready for Twilio)

## Deployment Steps

### Option 1: Vercel (Recommended)

1. Push your code to GitHub/GitLab/Bitbucket

2. Go to [vercel.com](https://vercel.com) and sign in

3. Click "New Project" and import your repository

4. Configure environment variables:
   ```
   VITE_SUPABASE_URL=https://wictgouudlcvibbimcwj.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndpY3Rnb3V1ZGxjdmliYmltY3dqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMzNjg3NjEsImV4cCI6MjA3ODk0NDc2MX0.68o16hF4tJQiAwo0q5456iBbF0EsEkNDUTAcZ5z6tk8
   ```

5. Click "Deploy"

6. Your site will be live at `your-project.vercel.app`

### Option 2: Netlify

1. Push your code to GitHub/GitLab/Bitbucket

2. Go to [netlify.com](https://netlify.com) and sign in

3. Click "Add new site" > "Import an existing project"

4. Select your repository

5. Configure build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`

6. Add environment variables (same as Vercel)

7. Click "Deploy"

### Custom Domain Setup (reflectionsbarber.shop)

#### On Vercel:
1. Go to Project Settings > Domains
2. Click "Add Domain"
3. Enter `reflectionsbarber.shop`
4. Follow DNS configuration instructions
5. Add these DNS records at your domain registrar:
   ```
   Type: A
   Name: @
   Value: 76.76.21.21

   Type: CNAME
   Name: www
   Value: cname.vercel-dns.com
   ```

#### On Netlify:
1. Go to Site Settings > Domain Management
2. Click "Add custom domain"
3. Enter `reflectionsbarber.shop`
4. Add DNS records at your domain registrar:
   ```
   Type: A
   Name: @
   Value: 75.2.60.5

   Type: CNAME
   Name: www
   Value: your-site.netlify.app
   ```

## Initial Setup After Deployment

### 1. Create Your Admin Account

1. Visit your deployed site
2. Click "Sign Up"
3. Create an account with your email
4. Go to [Supabase Dashboard](https://supabase.com/dashboard)
5. Navigate to: SQL Editor
6. Run this query:
   ```sql
   UPDATE profiles SET role = 'admin' WHERE email = 'your-email@example.com';
   ```
7. Sign out and sign back in
8. You now have full admin access!

### 2. Customize Barbers

1. Go to Admin Dashboard > Barbers
2. Edit existing barbers:
   - Change names (Mario, Juan, Carlos, etc.)
   - Add bios
   - Set Instagram handles
   - Configure working hours
   - Set days off
3. Add more barbers if needed (up to 15)
4. Toggle inactive barbers off

### 3. Update Contact Information

Edit `src/components/LandingPage.tsx`:

Line 57: Update phone number
```typescript
<a href="tel:732-XXX-XXXX">
  <span className="font-semibold">732-XXX-XXXX</span>
</a>
```

Line 64: Update Instagram handle
```typescript
<a href="https://instagram.com/your-handle">
  <span className="font-semibold">@your-handle</span>
</a>
```

### 4. Import Existing Data (Optional)

If migrating from Squire:

1. Export your data from Squire
2. Go to Admin Dashboard > Import
3. Get barber and service IDs from the database
4. Format your CSV with correct headers
5. Paste and import

## API Access

Your API is live at:
```
https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api
```

Available endpoints:
- `GET /availability?barber=ID&date=YYYY-MM-DD` - Check availability
- `POST /bookings` - Create new booking
- `GET /bookings` - List all bookings
- `GET /bookings/:id` - Get specific booking

See `API_DOCUMENTATION.md` for complete details.

## Testing Checklist

Before going live, test:

- [ ] Sign up as a client
- [ ] Book an appointment
- [ ] Sign up as a barber (set role manually)
- [ ] View barber dashboard
- [ ] Set yourself as admin
- [ ] Access admin dashboard
- [ ] Create/edit barbers
- [ ] View reports
- [ ] Test on mobile device
- [ ] Test booking flow end-to-end

## Optional Enhancements

### Enable SMS Notifications

1. Create [Twilio account](https://www.twilio.com/try-twilio)
2. Get Account SID, Auth Token, and phone number
3. Add secrets to Supabase:
   - Go to Project Settings > Edge Functions
   - Add secrets: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER`
4. Create new Edge Function for SMS:
   ```typescript
   import Twilio from 'npm:twilio';

   const client = Twilio(
     Deno.env.get('TWILIO_ACCOUNT_SID'),
     Deno.env.get('TWILIO_AUTH_TOKEN')
   );

   // Send SMS on booking creation
   await client.messages.create({
     body: 'Your appointment is confirmed!',
     from: Deno.env.get('TWILIO_PHONE_NUMBER'),
     to: clientPhone
   });
   ```

### Add Payment Processing

To add Stripe for deposits/payments, follow: https://bolt.new/setup/stripe

### Advanced Features

- Email confirmations via SendGrid
- Review system for barbers
- Loyalty/rewards program
- Waiting list for fully booked slots
- Service packages and memberships
- Photo gallery of work
- Online store for products

## Monitoring & Analytics

### Supabase Dashboard
Monitor your database, users, and API usage at:
https://supabase.com/dashboard/project/wictgouudlcvibbimcwj

### Vercel/Netlify Analytics
Both platforms provide built-in analytics for:
- Page views
- Performance metrics
- Geographic distribution
- Error tracking

## Support Resources

- **Setup Guide**: See `SETUP_GUIDE.md`
- **API Docs**: See `API_DOCUMENTATION.md`
- **Database Scripts**: See `admin-setup.sql`
- **Supabase Docs**: https://supabase.com/docs
- **React Docs**: https://react.dev

## Backup & Maintenance

### Database Backups
Supabase automatically backs up your database. To download:
1. Go to Supabase Dashboard
2. Database > Backups
3. Download as needed

### Updates
To update your app:
1. Make changes locally
2. Test with `npm run dev`
3. Build with `npm run build`
4. Push to Git
5. Vercel/Netlify auto-deploys

## Security Best Practices

- Never commit `.env` file to Git
- Rotate Supabase keys periodically
- Monitor admin account access
- Review RLS policies regularly
- Keep dependencies updated
- Enable 2FA on Supabase account

## Troubleshooting

### Build Fails
- Run `npm install` to ensure dependencies are installed
- Check for TypeScript errors with `npm run typecheck`
- Verify all environment variables are set

### Can't Sign In
- Check Supabase Auth settings
- Verify email confirmation is disabled (or handle it)
- Check browser console for errors

### Bookings Not Saving
- Verify RLS policies in Supabase
- Check Edge Function logs
- Ensure all required fields are provided

### Calendar Not Loading
- Check browser console for errors
- Verify barber and service data exists
- Check date format (YYYY-MM-DD)

## Production Checklist

- [ ] Environment variables configured
- [ ] Admin account created
- [ ] Barbers customized
- [ ] Contact info updated
- [ ] Custom domain configured
- [ ] SSL certificate active
- [ ] Mobile testing complete
- [ ] Booking flow tested
- [ ] API endpoints tested
- [ ] Backup strategy in place

## Next Steps

1. Deploy to Vercel/Netlify
2. Configure custom domain
3. Create admin account
4. Customize barbers and services
5. Test all functionality
6. Train your team
7. Go live!

Your barbershop booking system is production-ready and scalable for 10-15 barbers. The foundation is solid and can be extended with additional features as needed.

Good luck with Reflections Barbershop!
