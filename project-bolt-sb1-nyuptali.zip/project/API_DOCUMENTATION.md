# Reflections Barbershop API Documentation

## Base URL

```
https://wictgouudlcvibbimcwj.supabase.co/functions/v1
```

## Authentication

All API endpoints support optional JWT authentication via the `Authorization` header:

```
Authorization: Bearer YOUR_JWT_TOKEN
```

For public endpoints, you can use the anon key in the `apikey` header.

## Endpoints

### 1. Get Availability

Check available time slots for a specific barber on a given date.

**Endpoint:** `GET /bookings-api/availability`

**Query Parameters:**
- `barber` (required) - Barber UUID
- `date` (required) - Date in YYYY-MM-DD format

**Example Request:**
```bash
curl "https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/availability?barber=abc-123&date=2024-01-15"
```

**Example Response:**
```json
{
  "bookings": [
    {
      "start_time": "10:00:00",
      "end_time": "10:30:00"
    },
    {
      "start_time": "14:00:00",
      "end_time": "14:45:00"
    }
  ],
  "barber": {
    "start_time": "09:00:00",
    "end_time": "19:00:00",
    "days_off": ["sunday"]
  }
}
```

### 2. Create Booking

Create a new appointment booking.

**Endpoint:** `POST /bookings-api/bookings`

**Request Body:**
```json
{
  "barber_id": "uuid",
  "service_id": "uuid",
  "booking_date": "2024-01-15",
  "start_time": "10:00:00",
  "client_name": "John Doe",
  "client_phone": "555-0100",
  "client_email": "john@example.com"
}
```

**Required Fields:**
- `barber_id` - UUID of the barber
- `service_id` - UUID of the service
- `booking_date` - Date in YYYY-MM-DD format
- `start_time` - Time in HH:MM:SS format
- `client_name` - Client's full name

**Optional Fields:**
- `client_phone` - Client's phone number
- `client_email` - Client's email address

**Example Request:**
```bash
curl -X POST "https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings" \
  -H "Content-Type: application/json" \
  -d '{
    "barber_id": "abc-123",
    "service_id": "def-456",
    "booking_date": "2024-01-15",
    "start_time": "10:00:00",
    "client_name": "John Doe",
    "client_phone": "555-0100",
    "client_email": "john@example.com"
  }'
```

**Success Response (201):**
```json
{
  "success": true,
  "booking": {
    "id": "booking-uuid",
    "barber_id": "abc-123",
    "service_id": "def-456",
    "booking_date": "2024-01-15",
    "start_time": "10:00:00",
    "end_time": "10:30:00",
    "client_name": "John Doe",
    "client_phone": "555-0100",
    "client_email": "john@example.com",
    "status": "confirmed",
    "created_at": "2024-01-14T12:00:00Z"
  }
}
```

**Error Response (400):**
```json
{
  "error": "Missing required fields"
}
```

### 3. Get All Bookings

Retrieve all bookings (limited to last 50).

**Endpoint:** `GET /bookings-api/bookings`

**Example Request:**
```bash
curl "https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings"
```

**Example Response:**
```json
[
  {
    "id": "booking-uuid",
    "booking_date": "2024-01-15",
    "start_time": "10:00:00",
    "end_time": "10:30:00",
    "client_name": "John Doe",
    "status": "confirmed",
    "barbers": {
      "display_name": "Mario"
    },
    "services": {
      "name": "Fade",
      "price": 35.00
    }
  }
]
```

### 4. Get Single Booking

Retrieve a specific booking by ID.

**Endpoint:** `GET /bookings-api/bookings/:id`

**Example Request:**
```bash
curl "https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings/booking-uuid"
```

**Example Response:**
```json
{
  "id": "booking-uuid",
  "booking_date": "2024-01-15",
  "start_time": "10:00:00",
  "end_time": "10:30:00",
  "client_name": "John Doe",
  "client_phone": "555-0100",
  "client_email": "john@example.com",
  "status": "confirmed",
  "notes": "",
  "barbers": {
    "display_name": "Mario"
  },
  "services": {
    "name": "Fade",
    "price": 35.00
  }
}
```

## Direct Database Access via Supabase Client

For more complex queries, use the Supabase JavaScript client:

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Get active barbers
const { data: barbers } = await supabase
  .from('barbers')
  .select('*')
  .eq('is_active', true);

// Get services
const { data: services } = await supabase
  .from('services')
  .select('*')
  .eq('is_active', true);

// Get bookings for a specific date
const { data: bookings } = await supabase
  .from('bookings')
  .select('*, barbers(*), services(*)')
  .eq('booking_date', '2024-01-15')
  .in('status', ['pending', 'confirmed']);
```

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request (missing or invalid parameters)
- `404` - Not Found
- `500` - Internal Server Error

## Rate Limiting

Currently no rate limiting is implemented. Consider adding rate limiting for production use.

## CORS

All endpoints support CORS with the following headers:
- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type, Authorization, X-Client-Info, Apikey`

## Error Handling

All errors return JSON with an `error` field:

```json
{
  "error": "Error message describing what went wrong"
}
```

## Integration Examples

### JavaScript/Node.js
```javascript
const response = await fetch('https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    barber_id: 'abc-123',
    service_id: 'def-456',
    booking_date: '2024-01-15',
    start_time: '10:00:00',
    client_name: 'John Doe',
    client_phone: '555-0100',
    client_email: 'john@example.com'
  })
});

const data = await response.json();
console.log(data);
```

### Python
```python
import requests

url = 'https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings'
data = {
    'barber_id': 'abc-123',
    'service_id': 'def-456',
    'booking_date': '2024-01-15',
    'start_time': '10:00:00',
    'client_name': 'John Doe',
    'client_phone': '555-0100',
    'client_email': 'john@example.com'
}

response = requests.post(url, json=data)
print(response.json())
```

### cURL
```bash
curl -X POST "https://wictgouudlcvibbimcwj.supabase.co/functions/v1/bookings-api/bookings" \
  -H "Content-Type: application/json" \
  -d '{
    "barber_id": "abc-123",
    "service_id": "def-456",
    "booking_date": "2024-01-15",
    "start_time": "10:00:00",
    "client_name": "John Doe",
    "client_phone": "555-0100",
    "client_email": "john@example.com"
  }'
```

## Webhook Support

To receive notifications when bookings are created/updated, you can:

1. Set up database triggers in Supabase
2. Create an Edge Function to forward events to your webhook endpoint
3. Use Supabase Realtime subscriptions

Example Realtime subscription:
```typescript
const channel = supabase
  .channel('bookings')
  .on('postgres_changes',
    { event: 'INSERT', schema: 'public', table: 'bookings' },
    (payload) => {
      console.log('New booking:', payload.new);
      // Send to your webhook
    }
  )
  .subscribe();
```
