# White Page Debugging Guide

## Current Status

✅ Build successful (6.85s)
✅ All files present in dist/
✅ Environment variables configured
✅ Database policies fixed (no recursion)
✅ Extensive logging added

## If You're Seeing a White Page

### Step 1: Open Browser Console

**Chrome/Edge:**
- Press `F12` or `Ctrl+Shift+I` (Windows)
- Press `Cmd+Option+I` (Mac)
- Or Right-click → Inspect → Console tab

**Firefox:**
- Press `F12` or `Ctrl+Shift+K` (Windows)
- Press `Cmd+Option+K` (Mac)

**Safari:**
- Enable Developer Menu: Safari → Preferences → Advanced → "Show Develop menu"
- Press `Cmd+Option+C`

### Step 2: Look for Console Messages

You should see these logs if app is loading:
```
Starting Reflections Barber App...
Environment: { supabaseUrl: 'Set', supabaseKey: 'Set' }
App rendered successfully
App mounted
Fetching services...
Services fetched: 5
Render state: { loading: false, user: false, profile: false, currentView: 'landing' }
```

### Step 3: Check for Errors

Look for RED error messages in console:
- `Error fetching profile:` - Profile query issue
- `Error fetching services:` - Service query issue
- `Error rendering app:` - React rendering issue
- `Missing Supabase environment variables` - .env not loaded
- `Uncaught Error` - JavaScript error

### Step 4: Common Issues & Solutions

#### Issue 1: Supabase Environment Variables Missing
**Console shows:** `Missing Supabase environment variables`

**Solution:**
1. Check `.env` file exists in project root
2. Verify it contains:
```
VITE_SUPABASE_URL=https://wictgouudlcvibbimcwj.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI...
```
3. Restart dev server: `npm run dev`

#### Issue 2: Profile Query Error
**Console shows:** `Error fetching profile: infinite recursion detected`

**Solution:** Already fixed with migration `fix_profiles_rls_infinite_recursion.sql`

If still occurring:
```sql
-- Run this to verify policies are fixed
SELECT policyname FROM pg_policies WHERE tablename = 'profiles';
```

#### Issue 3: Services Query Error
**Console shows:** `Error fetching services: ...`

**Solution:**
1. Check services table exists:
```sql
SELECT COUNT(*) FROM services WHERE is_active = true;
```
2. Should return 5 services

#### Issue 4: Loading Never Finishes
**Console shows:** Stuck on "Loading..." or "Initializing application"

**Symptoms:**
- `loading: true` never changes to `false`
- Profile fetch hanging

**Solution:**
1. Check browser Network tab (F12 → Network)
2. Look for failed requests to `supabase.co`
3. Check if requests are returning 500 errors
4. If 500 errors, check database policies

#### Issue 5: CORS Error
**Console shows:** `Access-Control-Allow-Origin` error

**Solution:**
This shouldn't happen with Supabase, but if it does:
1. Check Supabase project is active
2. Verify ANON key is correct
3. Check Supabase dashboard for API settings

#### Issue 6: React Rendering Error
**Console shows:** `Uncaught Error: ...` with React stack trace

**Solution:**
1. Check which component is failing
2. Look at the error message
3. Common causes:
   - Missing data causing null reference
   - Invalid props
   - Hook usage outside component

## Debugging Commands

### Check Environment Variables (Dev Server)
```bash
# Should print the Supabase URL
echo $VITE_SUPABASE_URL
```

### Test Database Connection
```sql
-- Test profiles query
SELECT id, email, role FROM profiles LIMIT 1;

-- Test services query
SELECT id, name, price FROM services WHERE is_active = true;

-- Test barbers query
SELECT id, display_name FROM barbers WHERE is_active = true LIMIT 1;
```

### Verify Build
```bash
# Check dist folder
ls -lh dist/

# Should show:
# - index.html
# - assets/ folder
# - _redirects file
```

### Test Supabase Connection
```bash
# From browser console:
const { data, error } = await supabase.from('services').select('*').limit(1);
console.log('Data:', data, 'Error:', error);
```

## Expected Console Output (Successful Load)

```
Starting Reflections Barber App...
Environment: {supabaseUrl: "Set", supabaseKey: "Set"}
App rendered successfully
App mounted
Fetching services...
Services fetched: 5
Render state: {loading: false, user: false, profile: false, currentView: "landing"}
```

## What to Report If Still Broken

If you're still seeing a white page after checking the above:

1. **Open browser console** (F12)
2. **Copy ALL error messages** (red text)
3. **Copy ALL console logs**
4. **Take a screenshot** of console
5. **Check Network tab:**
   - Any failed requests?
   - Any 500 errors?
   - Any 403/401 errors?

## Testing Checklist

- [ ] Browser console open (F12)
- [ ] Check for error messages (red text)
- [ ] Verify environment logs show "Set" for both variables
- [ ] Check Network tab for failed requests
- [ ] Verify "App rendered successfully" message
- [ ] Verify "Services fetched: 5" message
- [ ] Check for profile fetch errors
- [ ] Hard refresh page (Ctrl+Shift+R or Cmd+Shift+R)
- [ ] Try incognito/private browsing mode
- [ ] Clear browser cache

## Files with Debug Logging

1. **`src/main.tsx`**
   - Logs environment variables
   - Logs app render success/failure
   - Shows if root element found

2. **`src/App.tsx`**
   - Logs when app mounts
   - Logs services fetch
   - Logs render state (loading, user, profile, view)

3. **`src/contexts/AuthContext.tsx`**
   - Logs profile fetch attempts
   - Logs profile fetch success/errors
   - Logs authentication state changes

4. **`src/components/BookingCalendar.tsx`**
   - Logs component mount
   - Logs services/barbers loading
   - Logs booking creation steps

## Quick Fixes

### If white page with NO console errors:
```bash
# Hard refresh
Ctrl+Shift+R (Windows)
Cmd+Shift+R (Mac)

# Or clear cache
# Chrome: Ctrl+Shift+Delete → Clear cache
# Then reload
```

### If "Loading..." stuck forever:
- Check browser console for errors
- Check Network tab for hanging requests
- Verify Supabase project is online (visit dashboard)

### If console shows environment variables missing:
```bash
# Restart dev server
# 1. Stop current server (Ctrl+C)
# 2. Run again
npm run dev
```

## Production Deployment

If deploying to production (Netlify/Vercel):

1. Ensure environment variables are set in hosting dashboard
2. Use **exact same names**:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Rebuild after setting env vars
4. Check build logs for errors

## Database Health Check

```sql
-- Check all tables exist
SELECT tablename FROM pg_tables WHERE schemaname = 'public';

-- Should return:
-- profiles, barbers, services, bookings, availability_overrides

-- Check RLS enabled
SELECT tablename, rowsecurity FROM pg_tables
WHERE schemaname = 'public' AND tablename IN ('profiles', 'bookings', 'services', 'barbers');

-- Should all show: rowsecurity = true

-- Check policies exist and have no recursion
SELECT tablename, policyname
FROM pg_policies
WHERE schemaname = 'public';

-- Should show 3 policies for profiles (select, insert, update)
```

## Still Not Working?

If you've tried all the above and still have a white page:

1. **Share console output** - Copy all logs and errors
2. **Share network errors** - Any failed requests?
3. **Share error details** - Specific error messages?
4. **Try different browser** - Chrome, Firefox, Safari
5. **Try incognito mode** - Rules out extension conflicts

The app now has extensive debugging. The console will tell you exactly what's wrong!

## Verification

✅ Build: 326KB bundle generated
✅ Logging: Added to main.tsx, App.tsx, AuthContext.tsx
✅ Error handling: Try-catch blocks added
✅ Environment: Variables logged on startup
✅ Database: Policies fixed (no recursion)
✅ Files: All present in dist/

**Next step: Open browser console and share what you see!**
