-- Team Management Script for Reflections Barbershop
-- Quick reference SQL commands for managing your 15-person team

-- =====================================================
-- 1. VIEW ALL TEAM MEMBERS
-- =====================================================

SELECT
  display_name as name,
  bio,
  is_active as active,
  start_time,
  end_time,
  days_off,
  instagram_handle
FROM barbers
ORDER BY display_name;

-- =====================================================
-- 2. SET MARIO AS ADMIN
-- =====================================================

-- Step 1: Mario creates account on the website
-- Step 2: Run these commands (replace with Mario's actual email)

UPDATE profiles
SET role = 'admin'
WHERE email = 'mario@reflectionsbarber.shop';

-- Link Mario's user account to his barber profile
UPDATE barbers
SET user_id = (
  SELECT id FROM profiles
  WHERE email = 'mario@reflectionsbarber.shop'
)
WHERE display_name = 'Mario';

-- =====================================================
-- 3. SET GUS AS CO-OWNER/ADMIN
-- =====================================================

-- After Gus creates his account
UPDATE profiles
SET role = 'admin'
WHERE email = 'gus@reflectionsbarber.shop';

UPDATE barbers
SET user_id = (
  SELECT id FROM profiles
  WHERE email = 'gus@reflectionsbarber.shop'
)
WHERE display_name = 'Gus';

-- =====================================================
-- 4. UPDATE A BARBER'S WORKING HOURS
-- =====================================================

-- Example: Change Mario's hours
UPDATE barbers
SET
  start_time = '08:00:00',
  end_time = '20:00:00',
  days_off = ARRAY['sunday']
WHERE display_name = 'Mario';

-- =====================================================
-- 5. UPDATE MULTIPLE BARBERS' HOURS AT ONCE
-- =====================================================

-- Set all barbers to same hours (customize as needed)
UPDATE barbers
SET
  start_time = '09:00:00',
  end_time = '19:00:00'
WHERE display_name IN ('Ivan', 'Tony', 'Jahmar');

-- =====================================================
-- 6. TEMPORARILY DEACTIVATE A BARBER
-- =====================================================

-- For vacation, leave, etc.
UPDATE barbers
SET is_active = false
WHERE display_name = 'Edwin';

-- Reactivate when they return
UPDATE barbers
SET is_active = true
WHERE display_name = 'Edwin';

-- =====================================================
-- 7. UPDATE BARBER PHOTO
-- =====================================================

UPDATE barbers
SET photo_url = 'https://example.com/photos/mario-new.jpg'
WHERE display_name = 'Mario';

-- =====================================================
-- 8. UPDATE BARBER BIO
-- =====================================================

UPDATE barbers
SET bio = 'Co-owner and master barber. 15+ years experience. Fade specialist.'
WHERE display_name = 'Mario';

-- =====================================================
-- 9. ADD INSTAGRAM HANDLES
-- =====================================================

UPDATE barbers
SET instagram_handle = '@mario732barber'
WHERE display_name = 'Mario';

UPDATE barbers
SET instagram_handle = '@gus_barber'
WHERE display_name = 'Gus';

-- =====================================================
-- 10. VIEW TODAY'S SCHEDULE FOR ALL BARBERS
-- =====================================================

SELECT
  b.display_name as barber,
  bk.start_time,
  bk.end_time,
  bk.client_name,
  s.name as service,
  bk.status
FROM bookings bk
JOIN barbers b ON bk.barber_id = b.id
JOIN services s ON bk.service_id = s.id
WHERE bk.booking_date = CURRENT_DATE
ORDER BY b.display_name, bk.start_time;

-- =====================================================
-- 11. VIEW SPECIFIC BARBER'S SCHEDULE
-- =====================================================

SELECT
  bk.booking_date,
  bk.start_time,
  bk.end_time,
  bk.client_name,
  bk.client_phone,
  s.name as service,
  bk.status
FROM bookings bk
JOIN services s ON bk.service_id = s.id
WHERE bk.barber_id = (SELECT id FROM barbers WHERE display_name = 'Mario')
AND bk.booking_date >= CURRENT_DATE
ORDER BY bk.booking_date, bk.start_time;

-- =====================================================
-- 12. REVENUE BY BARBER
-- =====================================================

SELECT
  b.display_name as barber,
  COUNT(*) as total_bookings,
  SUM(s.price) as total_revenue,
  SUM(CASE WHEN bk.booking_date >= CURRENT_DATE - INTERVAL '7 days' THEN s.price ELSE 0 END) as week_revenue,
  SUM(CASE WHEN bk.booking_date >= CURRENT_DATE - INTERVAL '30 days' THEN s.price ELSE 0 END) as month_revenue
FROM bookings bk
JOIN barbers b ON bk.barber_id = b.id
JOIN services s ON bk.service_id = s.id
WHERE bk.status IN ('completed', 'confirmed')
GROUP BY b.display_name
ORDER BY total_revenue DESC;

-- =====================================================
-- 13. SET DAYS OFF FOR MULTIPLE BARBERS
-- =====================================================

-- Example: Set Sunday off for most barbers
UPDATE barbers
SET days_off = ARRAY['sunday']
WHERE display_name IN ('Mario', 'Gus', 'Ivan', 'Tony', 'Norges', 'David', 'Hugo', 'Izabella');

-- Example: Set Sunday and Monday off for part-timers
UPDATE barbers
SET days_off = ARRAY['sunday', 'monday']
WHERE display_name IN ('Edwin', 'Nikki', 'Mario Jr', 'Maria');

-- =====================================================
-- 14. LINK BARBER TO THEIR USER ACCOUNT
-- =====================================================

-- After a barber creates their account, link it to their profile
UPDATE barbers
SET user_id = (SELECT id FROM profiles WHERE email = 'ivan@reflectionsbarber.shop')
WHERE display_name = 'Ivan';

-- Set their role to 'barber' so they can access their dashboard
UPDATE profiles
SET role = 'barber'
WHERE email = 'ivan@reflectionsbarber.shop';

-- =====================================================
-- 15. BULK UPDATE PHOTOS
-- =====================================================

-- If you have all photos uploaded, update all at once
UPDATE barbers SET photo_url = 'https://yourhost.com/team/mario.jpg' WHERE display_name = 'Mario';
UPDATE barbers SET photo_url = 'https://yourhost.com/team/gus.jpg' WHERE display_name = 'Gus';
UPDATE barbers SET photo_url = 'https://yourhost.com/team/ivan.jpg' WHERE display_name = 'Ivan';
-- ... continue for all 15 barbers

-- =====================================================
-- 16. VIEW TEAM PERFORMANCE SUMMARY
-- =====================================================

SELECT
  COUNT(DISTINCT b.id) as total_barbers,
  COUNT(DISTINCT CASE WHEN b.is_active THEN b.id END) as active_barbers,
  COUNT(bk.id) as total_bookings,
  SUM(CASE WHEN bk.booking_date >= CURRENT_DATE - INTERVAL '7 days' THEN 1 ELSE 0 END) as bookings_this_week,
  SUM(CASE WHEN bk.status = 'completed' THEN s.price ELSE 0 END) as total_revenue
FROM barbers b
LEFT JOIN bookings bk ON b.id = bk.barber_id
LEFT JOIN services s ON bk.service_id = s.id;

-- =====================================================
-- 17. FIND AVAILABLE TIME SLOTS FOR ANY BARBER TODAY
-- =====================================================

-- Shows which barbers have no bookings at specific times
SELECT
  b.display_name as available_barber,
  b.start_time as opens,
  b.end_time as closes
FROM barbers b
WHERE b.is_active = true
AND LOWER(TO_CHAR(CURRENT_DATE, 'Day')) <> ALL(b.days_off)
AND NOT EXISTS (
  SELECT 1 FROM bookings bk
  WHERE bk.barber_id = b.id
  AND bk.booking_date = CURRENT_DATE
  AND bk.start_time <= '14:00:00'
  AND bk.end_time > '14:00:00'
)
ORDER BY b.display_name;

-- =====================================================
-- 18. BACKUP TEAM DATA
-- =====================================================

-- Export all barber data (copy results to save as backup)
SELECT
  display_name,
  bio,
  photo_url,
  instagram_handle,
  is_active,
  start_time,
  end_time,
  ARRAY_TO_STRING(days_off, ',') as days_off
FROM barbers
ORDER BY display_name;

-- =====================================================
-- QUICK REFERENCE
-- =====================================================

-- View all barbers: SELECT * FROM barbers ORDER BY display_name;
-- View all bookings today: SELECT * FROM bookings WHERE booking_date = CURRENT_DATE;
-- Set someone as admin: UPDATE profiles SET role = 'admin' WHERE email = 'email@example.com';
-- Change barber hours: UPDATE barbers SET start_time = 'HH:MM:SS', end_time = 'HH:MM:SS' WHERE display_name = 'Name';
-- Deactivate barber: UPDATE barbers SET is_active = false WHERE display_name = 'Name';