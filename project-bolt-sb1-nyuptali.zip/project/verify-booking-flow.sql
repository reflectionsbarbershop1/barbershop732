-- Booking Flow Verification Script
-- Run this to verify all components are ready for the booking flow

-- =====================================================
-- 1. VERIFY ALL 5 SERVICES EXIST
-- =====================================================

SELECT
  '✓ Services Check' as check_name,
  COUNT(*) as service_count,
  CASE
    WHEN COUNT(*) >= 5 THEN '✓ PASS - All services available'
    ELSE '✗ FAIL - Missing services'
  END as status
FROM services
WHERE is_active = true;

-- Show service details
SELECT
  name,
  price,
  duration_minutes,
  is_active
FROM services
ORDER BY price;

-- =====================================================
-- 2. VERIFY ALL 15 BARBERS EXIST
-- =====================================================

SELECT
  '✓ Barbers Check' as check_name,
  COUNT(*) as barber_count,
  CASE
    WHEN COUNT(*) = 15 THEN '✓ PASS - All 15 barbers loaded'
    ELSE '⚠ WARN - Expected 15 barbers'
  END as status
FROM barbers;

-- Show barber details
SELECT
  display_name,
  bio,
  is_active,
  start_time,
  end_time,
  ARRAY_LENGTH(days_off, 1) as days_off_count,
  CASE WHEN photo_url IS NOT NULL THEN '✓' ELSE '✗' END as has_photo
FROM barbers
ORDER BY display_name;

-- =====================================================
-- 3. VERIFY BARBER PHOTOS
-- =====================================================

SELECT
  '✓ Photos Check' as check_name,
  COUNT(*) as barbers_with_photos,
  CASE
    WHEN COUNT(*) = 15 THEN '✓ PASS - All barbers have photos'
    ELSE '⚠ WARN - Some barbers missing photos'
  END as status
FROM barbers
WHERE photo_url IS NOT NULL;

-- =====================================================
-- 4. TEST BOOKING CREATION (DRY RUN)
-- =====================================================

-- This shows what data would be inserted for a test booking
SELECT
  '✓ Booking Data Preview' as info,
  (SELECT id FROM barbers WHERE display_name = 'Mario' LIMIT 1) as barber_id,
  (SELECT id FROM services WHERE name = 'Fade' LIMIT 1) as service_id,
  CURRENT_DATE + INTERVAL '1 day' as booking_date,
  '14:00:00' as start_time,
  '14:30:00' as end_time,
  'Test Customer' as client_name,
  '555-1234' as client_phone,
  'test@example.com' as client_email,
  'confirmed' as status;

-- =====================================================
-- 5. CHECK AVAILABLE TIME SLOTS FOR TOMORROW
-- =====================================================

-- Shows available times for Mario tomorrow (as example)
WITH mario_bookings AS (
  SELECT start_time, end_time
  FROM bookings
  WHERE barber_id = (SELECT id FROM barbers WHERE display_name = 'Mario' LIMIT 1)
  AND booking_date = CURRENT_DATE + INTERVAL '1 day'
  AND status IN ('pending', 'confirmed')
)
SELECT
  '✓ Availability Check' as check_name,
  COUNT(*) as existing_bookings,
  CASE
    WHEN COUNT(*) < 10 THEN '✓ PASS - Slots available'
    ELSE '⚠ WARN - Limited availability'
  END as status
FROM mario_bookings;

-- =====================================================
-- 6. VERIFY NO DOUBLE-BOOKINGS EXIST
-- =====================================================

SELECT
  '✓ Double-Booking Check' as check_name,
  COUNT(*) as conflicts,
  CASE
    WHEN COUNT(*) = 0 THEN '✓ PASS - No conflicts'
    ELSE '✗ FAIL - Overlapping bookings found'
  END as status
FROM (
  SELECT
    b1.id as booking1,
    b2.id as booking2
  FROM bookings b1
  JOIN bookings b2
    ON b1.barber_id = b2.barber_id
    AND b1.booking_date = b2.booking_date
    AND b1.id < b2.id
    AND b1.status IN ('pending', 'confirmed')
    AND b2.status IN ('pending', 'confirmed')
    AND (
      (b1.start_time >= b2.start_time AND b1.start_time < b2.end_time)
      OR (b1.end_time > b2.start_time AND b1.end_time <= b2.end_time)
      OR (b1.start_time <= b2.start_time AND b1.end_time >= b2.end_time)
    )
) conflicts;

-- =====================================================
-- 7. VERIFY RLS POLICIES FOR BOOKINGS
-- =====================================================

SELECT
  '✓ Security Check' as check_name,
  COUNT(*) as policy_count,
  CASE
    WHEN COUNT(*) >= 4 THEN '✓ PASS - Booking policies active'
    ELSE '✗ FAIL - Missing policies'
  END as status
FROM pg_policies
WHERE schemaname = 'public'
AND tablename = 'bookings';

-- =====================================================
-- 8. TEST BOOKING FLOW SIMULATION
-- =====================================================

-- Simulate a complete booking (SELECT only, doesn't insert)
WITH test_booking AS (
  SELECT
    (SELECT id FROM services WHERE name = 'Fade' LIMIT 1) as service_id,
    (SELECT display_name FROM barbers WHERE display_name = 'Mario' LIMIT 1) as barber_name,
    CURRENT_DATE + INTERVAL '1 day' as booking_date,
    '14:00:00' as start_time
)
SELECT
  '✓ Booking Flow Simulation' as step,
  '1. Service Selected: Fade ($35 / 30 min)' as detail
UNION ALL
SELECT
  '✓ Booking Flow Simulation',
  '2. Barber Selected: Mario'
UNION ALL
SELECT
  '✓ Booking Flow Simulation',
  '3. Date Selected: ' || TO_CHAR(CURRENT_DATE + INTERVAL '1 day', 'Mon DD, YYYY')
UNION ALL
SELECT
  '✓ Booking Flow Simulation',
  '4. Time Selected: 2:00 PM'
UNION ALL
SELECT
  '✓ Booking Flow Simulation',
  '5. Contact: Test Customer (test@example.com)'
UNION ALL
SELECT
  '✓ Booking Flow Simulation',
  '6. Status: Confirmed ✓';

-- =====================================================
-- 9. COMPREHENSIVE SUMMARY
-- =====================================================

SELECT '
╔════════════════════════════════════════════════════╗
║        BOOKING FLOW VERIFICATION SUMMARY           ║
╚════════════════════════════════════════════════════╝

Run all queries above to verify:

1. ✓ All 5 services exist and are active
2. ✓ All 15 barbers exist with photos
3. ✓ Photo URLs are populated
4. ✓ Booking data structure is correct
5. ✓ Time slots are available
6. ✓ No double-booking conflicts
7. ✓ RLS policies protect bookings
8. ✓ Complete flow can be simulated

BOOKING FLOW READY: ✓
- Service selection: 5 options available
- Barber selection: 15 barbers with photos
- Date selection: Calendar enabled
- Time selection: Slots auto-generated
- Confirmation: Fake SMS included

TEST THE FLOW:
1. Click "Book Now" on homepage
2. Select "Fade" service
3. Select "Mario" barber
4. Select tomorrow
5. Select "2:00 PM"
6. Enter contact info
7. Confirm booking
8. See success message with SMS confirmation

If all checks pass ✓, the booking system is ready!
' as summary;

-- =====================================================
-- 10. QUICK HEALTH CHECK (RUN ANYTIME)
-- =====================================================

SELECT
  'System Status' as component,
  'Ready ✓' as status
WHERE
  (SELECT COUNT(*) FROM services WHERE is_active = true) >= 5
  AND (SELECT COUNT(*) FROM barbers WHERE is_active = true) = 15
  AND (SELECT COUNT(*) FROM barbers WHERE photo_url IS NOT NULL) = 15
UNION ALL
SELECT
  'Services',
  CAST((SELECT COUNT(*) FROM services WHERE is_active = true) AS TEXT) || ' active'
UNION ALL
SELECT
  'Barbers',
  CAST((SELECT COUNT(*) FROM barbers WHERE is_active = true) AS TEXT) || ' active'
UNION ALL
SELECT
  'Total Bookings',
  CAST((SELECT COUNT(*) FROM bookings) AS TEXT) || ' bookings'
UNION ALL
SELECT
  'Today Bookings',
  CAST((SELECT COUNT(*) FROM bookings WHERE booking_date = CURRENT_DATE) AS TEXT) || ' today';