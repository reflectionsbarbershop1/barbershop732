#!/bin/bash

# Reflections Barber Shop - SSL Deployment Script
# This script prepares and deploys the application with SSL/HTTPS

set -e

echo "🔧 Reflections Barber Shop - SSL Deployment"
echo "============================================"
echo ""

# Step 1: Clean build
echo "📦 Step 1: Building application..."
npm run build
echo "✅ Build complete!"
echo ""

# Step 2: Verify files
echo "🔍 Step 2: Verifying deployment files..."
if [ -f "netlify.toml" ]; then
    echo "  ✅ netlify.toml (HSTS headers configured)"
else
    echo "  ❌ netlify.toml missing!"
    exit 1
fi

if [ -f "dist/_redirects" ]; then
    echo "  ✅ dist/_redirects (SPA routing configured)"
else
    echo "  ❌ dist/_redirects missing!"
    exit 1
fi

if [ -f "dist/index.html" ]; then
    echo "  ✅ dist/index.html (Application ready)"
else
    echo "  ❌ dist/index.html missing!"
    exit 1
fi
echo ""

# Step 3: Check for Netlify CLI
echo "🚀 Step 3: Checking deployment options..."
if command -v netlify &> /dev/null; then
    echo "  ✅ Netlify CLI found"
    echo ""
    read -p "Deploy to Netlify now? (y/n): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "  🚀 Deploying to Netlify..."
        netlify deploy --prod
        echo ""
        echo "  ✅ Deployed! Check Netlify dashboard for SSL status."
    else
        echo "  ⏭️  Skipping deployment"
    fi
else
    echo "  ℹ️  Netlify CLI not installed"
    echo "  Install: npm install -g netlify-cli"
fi
echo ""

# Step 4: Instructions
echo "📋 Next Steps:"
echo "============================================"
echo ""
echo "If you haven't deployed yet:"
echo "  1. Install Netlify CLI: npm install -g netlify-cli"
echo "  2. Login: netlify login"
echo "  3. Deploy: netlify deploy --prod"
echo ""
echo "After deployment:"
echo "  1. Go to: Netlify Dashboard > Domain Settings"
echo "  2. Add custom domain: reflectionsbarber.shop"
echo "  3. Add DNS records at your registrar:"
echo "     - Type: A, Name: @, Value: 75.2.60.5"
echo "     - Type: CNAME, Name: www, Value: [your-site].netlify.app"
echo "  4. Wait 5-30 minutes for DNS propagation"
echo "  5. SSL certificate will auto-issue (Let's Encrypt)"
echo "  6. Look for green checkmark: ✅ SSL active"
echo "  7. Enable 'Force HTTPS' in Netlify settings"
echo ""
echo "Security Features Included:"
echo "  ✅ HSTS headers (2 year max-age)"
echo "  ✅ Force HTTPS redirect"
echo "  ✅ XSS protection"
echo "  ✅ Clickjacking prevention"
echo "  ✅ Content Security Policy"
echo "  ✅ Let's Encrypt SSL (free, auto-renew)"
echo ""
echo "📖 Full instructions: See SSL_DEPLOYMENT_GUIDE.md"
echo ""
echo "✨ Application ready for secure HTTPS deployment!"
