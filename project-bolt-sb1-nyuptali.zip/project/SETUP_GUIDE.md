# Reflections Barbershop - Setup Guide

## Overview

A complete multi-barber booking system for 10-15 barbers with role-based access control, real-time availability, and comprehensive management features.

## Features Implemented

### Client Features
- Browse services and pricing
- Interactive booking calendar with real-time availability
- Guest booking or account creation
- Personal appointment history
- Cancel upcoming appointments
- Email confirmations

### Barber Features
- Personal dashboard with daily schedule
- View upcoming appointments
- Confirm/cancel bookings
- Mark appointments as completed
- Track daily revenue
- Client contact information

### Admin Features
- Comprehensive dashboard with statistics
- Manage all barbers (add/edit/remove)
- View all bookings across barbers
- Daily/total revenue tracking
- CSV import for data migration from Squire
- Manage services and pricing

## Database Schema

The system uses Supabase with the following tables:
- **profiles** - User accounts with role-based access (admin/barber/client)
- **barbers** - Barber information and availability
- **services** - Available services with pricing
- **bookings** - Appointment bookings with full details
- **barber_availability_exceptions** - Special hours/time off

## Pre-populated Data

### Services
1. Fade - $35 / 30 min
2. Lineup - $20 / 15 min
3. Beard Trim - $25 / 20 min
4. Full Service - $50 / 45 min
5. Kids Cut - $25 / 20 min

### Sample Barbers
1. Mario (Head barber, @mario732barber)
2. Juan (Fade specialist)
3. Carlos (Classic cuts expert)
4. Miguel (Modern styles)
5. Alex (Beard specialist)

## Getting Started

### 1. Create Admin Account

To access the admin dashboard, you need to create an account and manually set the role to 'admin':

```sql
-- After signing up, run this in Supabase SQL Editor:
UPDATE profiles SET role = 'admin' WHERE email = 'your-admin-email@example.com';
```

### 2. Create Barber Accounts

For each barber:
1. Create an account through the signup
2. Link the account to a barber profile in admin dashboard
3. Or manually set role to 'barber' and link in database

### 3. Customize Barbers

Admin dashboard allows you to:
- Add/edit barber names and bios
- Set Instagram handles
- Toggle active status
- Customize working hours (default: 9 AM - 7 PM)
- Set days off

### 4. Import Existing Data (Optional)

Use the CSV Import feature in Admin Dashboard to migrate data from Squire:

**Bookings CSV Format:**
```csv
barber_id,service_id,booking_date,start_time,end_time,client_name,client_phone,client_email,status
uuid-here,uuid-here,2024-01-15,10:00:00,10:30:00,John Doe,555-0100,john@email.com,confirmed
```

**Steps:**
1. Export data from Squire
2. Get barber and service UUIDs from Supabase
3. Format CSV with correct headers
4. Paste into Import tab in Admin Dashboard

## API Endpoints

The system includes RESTful API endpoints via Supabase Edge Functions:

### Get Availability
```
GET /bookings-api/availability?barber=BARBER_ID&date=YYYY-MM-DD
```

### Create Booking
```
POST /bookings-api/bookings
Body: {
  barber_id, service_id, booking_date, start_time,
  client_name, client_phone, client_email
}
```

### Get Bookings
```
GET /bookings-api/bookings
GET /bookings-api/bookings/BOOKING_ID
```

## SMS Notifications Setup (Optional)

To enable SMS reminders via Twilio:

1. Create Twilio account and get credentials
2. Add Twilio secrets to Supabase
3. Create Edge Function for SMS:

```typescript
// Example Twilio integration
import Twilio from 'npm:twilio';

const client = Twilio(accountSid, authToken);

await client.messages.create({
  body: 'Your appointment with Mario is tomorrow at 3pm',
  from: twilioNumber,
  to: clientPhone
});
```

4. Set up scheduled function to check for appointments 24 hours out

## User Roles

### Client
- Book appointments
- View personal booking history
- Cancel own appointments
- Update profile

### Barber
- View personal schedule
- Manage own appointments
- Update booking status
- View client details

### Admin
- Full system access
- Manage all barbers
- View all bookings
- Access reports and analytics
- Import data

## Security Features

- Row Level Security (RLS) enabled on all tables
- Role-based access control
- Secure authentication via Supabase Auth
- JWT-based API authentication
- Protected admin routes

## Mobile Responsive

The entire system is mobile-optimized with:
- Responsive navigation
- Touch-friendly booking calendar
- Mobile-first design
- Works on all screen sizes

## Production Deployment

The app is ready to deploy to Vercel/Netlify:

1. Connect your repository
2. Set environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Deploy!

## Custom Domain Setup

To use reflectionsbarber.shop:

1. Configure DNS records to point to your hosting provider
2. Add custom domain in Vercel/Netlify settings
3. Enable SSL certificate
4. Update any hardcoded URLs if needed

## Support & Customization

### Adding More Barbers
Use Admin Dashboard > Barbers > Add Barber

### Changing Services/Pricing
Direct database access or add service management to admin dashboard

### Customizing Hours
Edit barber settings in admin dashboard

### Branding
- Update contact info in LandingPage.tsx (line 53-68)
- Customize colors in tailwind.config.js
- Replace logo/icons as needed

## Technical Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Backend**: Supabase (PostgreSQL)
- **Auth**: Supabase Auth
- **API**: Supabase Edge Functions
- **Build**: Vite

## Contact Information

Update your contact details in the footer:
- Phone: 732 (line 57 in LandingPage.tsx)
- Instagram: @mario732barber (line 64)
- Domain: reflectionsbarber.shop (line 47)

## Development

```bash
npm install
npm run dev
```

Access at http://localhost:5173

Build for production:
```bash
npm run build
```

## Troubleshooting

### Can't access admin dashboard
Make sure your profile role is set to 'admin' in the database

### Bookings not showing
Check RLS policies and ensure user authentication is working

### Calendar slots not appearing
Verify barber working hours and check for conflicting bookings

### API endpoints not working
Ensure Edge Functions are deployed and environment variables are set
