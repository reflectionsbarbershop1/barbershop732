/*
  # Fix Profiles RLS Infinite Recursion

  ## Problem
  The profiles table policies had infinite recursion because they queried
  the profiles table from within the profiles table policy, creating a loop.

  ## Solution
  Store the user's role in JWT claims (app_metadata) so policies can check
  the role without querying the profiles table.

  ## Changes
  1. Drop existing policies with infinite recursion
  2. Create new policies that check auth.jwt() instead of querying profiles
  3. Update the handle_new_user trigger to set role in app_metadata
*/

-- =====================================================
-- 1. DROP EXISTING POLICIES
-- =====================================================

DROP POLICY IF EXISTS "profiles_select_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_update_policy" ON profiles;

-- =====================================================
-- 2. CREATE NEW POLICIES WITHOUT RECURSION
-- =====================================================

-- SELECT policy: Barbers are public, users see own profile, admins see all
CREATE POLICY "profiles_select_policy"
  ON profiles
  FOR SELECT
  TO public
  USING (
    role = 'barber'
    OR id = (SELECT auth.uid())
    OR (SELECT COALESCE(auth.jwt()->>'role', 'client')) = 'admin'
  );

-- INSERT policy: Only allow during signup (handled by trigger)
CREATE POLICY "profiles_insert_policy"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    id = (SELECT auth.uid())
    OR (SELECT COALESCE(auth.jwt()->>'role', 'client')) = 'admin'
  );

-- UPDATE policy: Users update own profile, admins update all
CREATE POLICY "profiles_update_policy"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = (SELECT auth.uid())
    OR (SELECT COALESCE(auth.jwt()->>'role', 'client')) = 'admin'
  )
  WITH CHECK (
    id = (SELECT auth.uid())
    OR (SELECT COALESCE(auth.jwt()->>'role', 'client')) = 'admin'
  );

-- =====================================================
-- 3. UPDATE TRIGGER TO SET ROLE IN JWT
-- =====================================================

-- Drop existing function
DROP FUNCTION IF EXISTS handle_new_user() CASCADE;

-- Create updated function that sets role in app_metadata
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role)
  VALUES (
    NEW.id,
    NEW.email,
    'client'
  );
  
  -- Note: Setting app_metadata requires service role key
  -- This will be set to 'client' by default
  -- Admins and barbers must be updated manually via dashboard
  
  RETURN NEW;
END;
$$;

-- Recreate trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- =====================================================
-- 4. VERIFY RLS IS ENABLED
-- =====================================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- 5. HELPER FUNCTION TO UPDATE USER ROLE IN JWT
-- =====================================================

-- This function can be called to sync role to JWT claims
-- Note: This is a simplified version, full implementation would
-- require service role access to update auth.users metadata

CREATE OR REPLACE FUNCTION update_user_role_claim()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- This is a placeholder
  -- In production, use Supabase Edge Functions or service role
  -- to update auth.users.raw_app_meta_data
  RETURN NEW;
END;
$$;
