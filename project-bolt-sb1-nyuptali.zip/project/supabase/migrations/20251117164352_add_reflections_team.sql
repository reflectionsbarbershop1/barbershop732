/*
  # Add Reflections Barbershop Team

  ## Changes
  
  1. Add photo_url column to barbers table
  2. Clear sample barbers
  3. Add actual 15-person team with roles and bios
  4. Set Mario as co-owner/admin ready
  
  ## Team Members
  
  1. Mario (co-owner) - Head barber, fade specialist
  2. Gus (co-owner) - Master barber, classic cuts
  3. Ivan - Modern styles expert
  4. Tony - Precision cuts specialist
  5. Jahmar - Fade and taper expert
  6. Edwin - Beard specialist
  7. Norges - Contemporary styling
  8. Alex - Texture specialist
  9. David - All-around barber
  10. Juan - Traditional cuts expert
  11. Nikki - Women's cuts specialist
  12. Hugo - Design and art cuts
  13. Mario Jr - Rising talent
  14. Izabella - Color and styling
  15. Maria - Family cuts specialist
*/

-- Add photo_url column to barbers table
ALTER TABLE barbers ADD COLUMN IF NOT EXISTS photo_url text;

-- Clear existing sample barbers
DELETE FROM barbers;

-- Insert Reflections Barbershop team
INSERT INTO barbers (display_name, bio, photo_url, instagram_handle, is_active, start_time, end_time, days_off) VALUES
  ('Mario', 'Co-owner and head barber. Master of fades and precision cuts.', 'https://images.pexels.com/photos/1319459/pexels-photo-1319459.jpeg?auto=compress&cs=tinysrgb&w=400', '@mario732barber', true, '09:00:00', '19:00:00', ARRAY['sunday']),
  ('Gus', 'Co-owner and master barber. Expert in classic cuts and styling.', 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '09:00:00', '19:00:00', ARRAY['sunday']),
  ('Ivan', 'Modern styles expert. Specializes in contemporary trends.', 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '19:00:00', ARRAY['monday']),
  ('Tony', 'Precision cuts specialist. Known for attention to detail.', 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '20:00:00', ARRAY['sunday']),
  ('Jahmar', 'Fade and taper expert. Master of gradient techniques.', 'https://images.pexels.com/photos/1139743/pexels-photo-1139743.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '11:00:00', '20:00:00', ARRAY['monday']),
  ('Edwin', 'Beard specialist. Expert grooming and shaping.', 'https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '09:00:00', '18:00:00', ARRAY['sunday', 'monday']),
  ('Norges', 'Contemporary styling specialist. Creative and innovative.', 'https://images.pexels.com/photos/1570806/pexels-photo-1570806.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '19:00:00', ARRAY['sunday']),
  ('Alex', 'Texture specialist. Expert with all hair types.', 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '09:00:00', '18:00:00', ARRAY['monday']),
  ('David', 'All-around barber. Versatile and reliable.', 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '19:00:00', ARRAY['sunday']),
  ('Juan', 'Traditional cuts expert. Classic barber techniques.', 'https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '09:00:00', '19:00:00', ARRAY['monday']),
  ('Nikki', 'Women''s cuts specialist. Expert in all styles.', 'https://images.pexels.com/photos/3992656/pexels-photo-3992656.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '18:00:00', ARRAY['sunday', 'monday']),
  ('Hugo', 'Design and art cuts. Creative pattern specialist.', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '11:00:00', '20:00:00', ARRAY['sunday']),
  ('Mario Jr', 'Rising talent. Learning from the best.', 'https://images.pexels.com/photos/1464230/pexels-photo-1464230.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '19:00:00', ARRAY['sunday', 'monday']),
  ('Izabella', 'Color and styling expert. Modern techniques.', 'https://images.pexels.com/photos/3992324/pexels-photo-3992324.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '10:00:00', '18:00:00', ARRAY['sunday']),
  ('Maria', 'Family cuts specialist. Great with kids and seniors.', 'https://images.pexels.com/photos/3992329/pexels-photo-3992329.jpeg?auto=compress&cs=tinysrgb&w=400', NULL, true, '09:00:00', '17:00:00', ARRAY['sunday', 'monday'])
ON CONFLICT DO NOTHING;

-- Add helpful comment
COMMENT ON COLUMN barbers.photo_url IS 'Profile photo URL - uses stock photos from Pexels by default, replace with actual team photos';

-- Note: To set Mario as admin, after he creates his account, run:
-- UPDATE profiles SET role = 'admin' WHERE email = 'mario@reflectionsbarber.shop';
-- UPDATE barbers SET user_id = (SELECT id FROM profiles WHERE email = 'mario@reflectionsbarber.shop') WHERE display_name = 'Mario';