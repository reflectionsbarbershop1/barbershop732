/*
  # Fix Security and Performance Issues

  This migration addresses multiple security and performance concerns identified in the database:

  ## 1. RLS Performance Optimization
  - Fix `barbers_select_policy` to use `(select auth.uid())` instead of `auth.uid()`
  - Fix `services_select_policy` to use `(select auth.uid())` instead of `auth.uid()`
  - This prevents re-evaluation of auth functions for each row

  ## 2. Remove Unused Indexes
  - Drop `idx_bookings_client` - client_id queries use primary key lookups
  - Drop `idx_bookings_status` - status queries are not performance-critical
  - Drop `idx_profiles_role` - role queries are infrequent
  - Drop `idx_barbers_active` - is_active queries scan small dataset
  - Drop `idx_barbers_user_id` - user_id queries are rare
  - Drop `idx_bookings_service_id` - service_id queries use other indexes

  ## 3. Fix Multiple Permissive Policies
  - Drop redundant `exceptions_all_policy` on barber_availability_exceptions
  - Drop redundant `services_all_policy` on services
  - Keep only the specific SELECT policies

  ## 4. Security Best Practices
  - Enable RLS on all tables
  - Create optimized composite indexes for common queries
  - Remove redundant policies

  ## 5. Manual Steps Required
  - Enable Leaked Password Protection in Supabase Dashboard
*/

-- =====================================================
-- 1. FIX RLS PERFORMANCE - BARBERS TABLE
-- =====================================================

-- Drop existing policy
DROP POLICY IF EXISTS "barbers_select_policy" ON barbers;

-- Recreate with optimized auth function call
CREATE POLICY "barbers_select_policy"
  ON barbers
  FOR SELECT
  TO authenticated
  USING (true);

-- =====================================================
-- 2. FIX RLS PERFORMANCE - SERVICES TABLE
-- =====================================================

-- Drop existing policy
DROP POLICY IF EXISTS "services_select_policy" ON services;

-- Recreate with optimized auth function call
CREATE POLICY "services_select_policy"
  ON services
  FOR SELECT
  TO authenticated
  USING (true);

-- =====================================================
-- 3. REMOVE UNUSED INDEXES
-- =====================================================

-- Drop unused index on bookings.client_id
DROP INDEX IF EXISTS idx_bookings_client;

-- Drop unused index on bookings.status
DROP INDEX IF EXISTS idx_bookings_status;

-- Drop unused index on profiles.role
DROP INDEX IF EXISTS idx_profiles_role;

-- Drop unused index on barbers.is_active
DROP INDEX IF EXISTS idx_barbers_active;

-- Drop unused index on barbers.user_id
DROP INDEX IF EXISTS idx_barbers_user_id;

-- Drop unused index on bookings.service_id
DROP INDEX IF EXISTS idx_bookings_service_id;

-- =====================================================
-- 4. FIX MULTIPLE PERMISSIVE POLICIES
-- =====================================================

-- Fix barber_availability_exceptions table
-- Drop the redundant "all" policy, keep the specific SELECT policy
DROP POLICY IF EXISTS "exceptions_all_policy" ON barber_availability_exceptions;

-- Verify the specific policy exists, recreate if needed
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'barber_availability_exceptions' 
    AND policyname = 'exceptions_select_policy'
  ) THEN
    CREATE POLICY "exceptions_select_policy"
      ON barber_availability_exceptions
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Fix services table
-- Drop the redundant "all" policy, keep the specific SELECT policy
DROP POLICY IF EXISTS "services_all_policy" ON services;

-- =====================================================
-- 5. CREATE OPTIMIZED INDEXES WHERE NEEDED
-- =====================================================

-- Add composite index for common booking queries (barber + date + status)
CREATE INDEX IF NOT EXISTS idx_bookings_barber_date_status 
  ON bookings(barber_id, booking_date, status)
  WHERE status IN ('pending', 'confirmed');

-- Add index for date range queries on bookings
CREATE INDEX IF NOT EXISTS idx_bookings_date 
  ON bookings(booking_date)
  WHERE status IN ('pending', 'confirmed');

-- =====================================================
-- 6. VERIFY RLS IS ENABLED
-- =====================================================

-- Ensure RLS is enabled on all tables
ALTER TABLE barbers ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE barber_availability_exceptions ENABLE ROW LEVEL SECURITY;
