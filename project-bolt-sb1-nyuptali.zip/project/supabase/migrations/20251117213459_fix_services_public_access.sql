/*
  # Fix Services Public Access

  Services need to be visible to everyone (not just authenticated users)
  so the landing page can display them.
*/

DROP POLICY IF EXISTS "services_select_policy" ON services;

CREATE POLICY "services_select_policy"
  ON services
  FOR SELECT
  TO public
  USING (is_active = true);
