/*
  # Reflections Barbershop Database Schema

  ## Overview
  Complete multi-barber booking system with role-based access control for 10-15 barbers.

  ## New Tables

  ### 1. `profiles`
  User profiles extending Supabase auth.users
  - `id` (uuid, FK to auth.users) - User ID
  - `email` (text) - User email
  - `phone` (text) - Phone number for SMS notifications
  - `full_name` (text) - Full name
  - `role` (text) - Role: 'admin', 'barber', 'client'
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `barbers`
  Barber-specific information
  - `id` (uuid, PK) - Barber ID
  - `user_id` (uuid, FK to profiles) - Link to user profile
  - `display_name` (text) - Display name for booking (e.g., "Mario", "Juan")
  - `bio` (text) - Short bio
  - `instagram_handle` (text) - Instagram handle
  - `is_active` (boolean) - Whether accepting bookings
  - `start_time` (time) - Daily start time
  - `end_time` (time) - Daily end time
  - `days_off` (text[]) - Array of days off (e.g., ['sunday', 'monday'])
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. `services`
  Available barbershop services
  - `id` (uuid, PK) - Service ID
  - `name` (text) - Service name (e.g., "Fade", "Lineup")
  - `description` (text) - Service description
  - `price` (numeric) - Price in dollars
  - `duration_minutes` (integer) - Duration in minutes
  - `is_active` (boolean) - Whether service is available
  - `created_at` (timestamptz)

  ### 4. `bookings`
  Appointment bookings
  - `id` (uuid, PK) - Booking ID
  - `barber_id` (uuid, FK to barbers) - Assigned barber
  - `client_id` (uuid, FK to profiles, nullable) - Client (null for guest bookings)
  - `service_id` (uuid, FK to services) - Booked service
  - `booking_date` (date) - Appointment date
  - `start_time` (time) - Start time
  - `end_time` (time) - End time
  - `status` (text) - Status: 'pending', 'confirmed', 'completed', 'cancelled', 'no_show'
  - `client_name` (text) - Name (for guest bookings)
  - `client_phone` (text) - Phone (for guest bookings)
  - `client_email` (text) - Email (for guest bookings)
  - `notes` (text) - Additional notes
  - `reminder_sent` (boolean) - Whether SMS reminder was sent
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 5. `barber_availability_exceptions`
  Special availability (vacations, breaks)
  - `id` (uuid, PK) - Exception ID
  - `barber_id` (uuid, FK to barbers) - Barber
  - `date` (date) - Exception date
  - `is_available` (boolean) - Available or not
  - `start_time` (time, nullable) - Custom start time
  - `end_time` (time, nullable) - Custom end time
  - `reason` (text) - Reason for exception
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Admins have full access
  - Barbers can view/edit their own data
  - Clients can view their own bookings
  - Public can view barbers and services for booking

  ## Indexes
  - Booking date/barber for fast availability queries
  - User role for permission checks
  - Service status for active services
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  phone text,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'client' CHECK (role IN ('admin', 'barber', 'client')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create barbers table
CREATE TABLE IF NOT EXISTS barbers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  bio text DEFAULT '',
  instagram_handle text,
  is_active boolean DEFAULT true,
  start_time time DEFAULT '09:00:00',
  end_time time DEFAULT '19:00:00',
  days_off text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  price numeric(10, 2) NOT NULL,
  duration_minutes integer NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  barber_id uuid NOT NULL REFERENCES barbers(id) ON DELETE CASCADE,
  client_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  service_id uuid NOT NULL REFERENCES services(id),
  booking_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled', 'no_show')),
  client_name text NOT NULL,
  client_phone text,
  client_email text,
  notes text DEFAULT '',
  reminder_sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create barber availability exceptions table
CREATE TABLE IF NOT EXISTS barber_availability_exceptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  barber_id uuid NOT NULL REFERENCES barbers(id) ON DELETE CASCADE,
  date date NOT NULL,
  is_available boolean DEFAULT false,
  start_time time,
  end_time time,
  reason text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_bookings_barber_date ON bookings(barber_id, booking_date);
CREATE INDEX IF NOT EXISTS idx_bookings_client ON bookings(client_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_barbers_active ON barbers(is_active);
CREATE INDEX IF NOT EXISTS idx_services_active ON services(is_active);
CREATE INDEX IF NOT EXISTS idx_availability_exceptions ON barber_availability_exceptions(barber_id, date);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE barbers ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE barber_availability_exceptions ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public can view barber profiles"
  ON profiles FOR SELECT
  USING (role = 'barber');

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert profiles"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update all profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Barbers policies
CREATE POLICY "Anyone can view active barbers"
  ON barbers FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated can view all barbers"
  ON barbers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Barbers can update own info"
  ON barbers FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can manage all barbers"
  ON barbers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Services policies
CREATE POLICY "Anyone can view active services"
  ON services FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated can view all services"
  ON services FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage services"
  ON services FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Bookings policies
CREATE POLICY "Anyone can view bookings for availability"
  ON bookings FOR SELECT
  USING (status IN ('confirmed', 'pending'));

CREATE POLICY "Anyone can create bookings"
  ON bookings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Clients can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (client_id = auth.uid());

CREATE POLICY "Clients can update own pending bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (client_id = auth.uid() AND status = 'pending')
  WITH CHECK (client_id = auth.uid() AND status IN ('pending', 'cancelled'));

CREATE POLICY "Barbers can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM barbers
      WHERE barbers.id = bookings.barber_id
      AND barbers.user_id = auth.uid()
    )
  );

CREATE POLICY "Barbers can update own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM barbers
      WHERE barbers.id = bookings.barber_id
      AND barbers.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM barbers
      WHERE barbers.id = bookings.barber_id
      AND barbers.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all bookings"
  ON bookings FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Availability exceptions policies
CREATE POLICY "Anyone can view availability exceptions"
  ON barber_availability_exceptions FOR SELECT
  USING (true);

CREATE POLICY "Barbers can manage own exceptions"
  ON barber_availability_exceptions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM barbers
      WHERE barbers.id = barber_availability_exceptions.barber_id
      AND barbers.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM barbers
      WHERE barbers.id = barber_availability_exceptions.barber_id
      AND barbers.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all exceptions"
  ON barber_availability_exceptions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Insert default services
INSERT INTO services (name, description, price, duration_minutes, is_active) VALUES
  ('Fade', 'Professional fade haircut', 35.00, 30, true),
  ('Lineup', 'Clean lineup and edge up', 20.00, 15, true),
  ('Beard Trim', 'Beard shaping and trim', 25.00, 20, true),
  ('Full Service', 'Haircut and beard trim combo', 50.00, 45, true),
  ('Kids Cut', 'Haircut for children under 12', 25.00, 20, true)
ON CONFLICT DO NOTHING;

-- Insert sample barbers (can be edited via admin dashboard)
INSERT INTO barbers (display_name, bio, instagram_handle, is_active) VALUES
  ('Mario', 'Head barber at Reflections', '@mario732barber', true),
  ('Juan', 'Fade specialist', NULL, true),
  ('Carlos', 'Expert in classic cuts', NULL, true),
  ('Miguel', 'Modern styles expert', NULL, true),
  ('Alex', 'Beard specialist', NULL, true)
ON CONFLICT DO NOTHING;

-- Create function to automatically create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
    COALESCE(NEW.raw_user_meta_data->>'role', 'client')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_barbers_updated_at BEFORE UPDATE ON barbers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();