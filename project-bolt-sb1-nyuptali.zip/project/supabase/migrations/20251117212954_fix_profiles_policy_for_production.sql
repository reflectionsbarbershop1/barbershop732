/*
  # Fix Profiles Policies for Production

  ## Problem
  The previous fix checked auth.jwt()->>'role' but this doesn't exist in JWT.
  The role is stored in the profiles table, not in JWT claims.
  
  ## Solution
  Simplify policies to:
  1. Allow public to see barbers
  2. Allow users to see their own profile
  3. Don't check admin status via JWT (not reliable)
  
  This avoids recursion while still being secure.
*/

-- Drop existing policies
DROP POLICY IF EXISTS "profiles_select_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_update_policy" ON profiles;

-- SELECT: Barbers are public, authenticated users see own profile
CREATE POLICY "profiles_select_policy"
  ON profiles
  FOR SELECT
  TO public
  USING (
    role = 'barber'
    OR (auth.uid() IS NOT NULL AND id = auth.uid())
  );

-- INSERT: Only during signup (user creates own profile)
CREATE POLICY "profiles_insert_policy"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (id = auth.uid());

-- UPDATE: Users can only update their own profile
CREATE POLICY "profiles_update_policy"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- DELETE: Users can delete their own profile (optional, uncomment if needed)
-- CREATE POLICY "profiles_delete_policy"
--   ON profiles
--   FOR DELETE
--   TO authenticated
--   USING (id = auth.uid());

-- Grant admin/barber special access via a separate service role
-- For admin operations, use the service role key (bypasses RLS)
