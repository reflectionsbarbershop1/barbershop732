/*
  # Fix Public Access for All Tables

  Landing page needs to load:
  - Services (to display)
  - Barbers (for booking)
  - Bookings (to show availability)
  
  All must be visible to anonymous users.
*/

-- Services: Already fixed, but ensure it's correct
DROP POLICY IF EXISTS "services_select_policy" ON services;
CREATE POLICY "services_select_policy"
  ON services FOR SELECT TO public
  USING (is_active = true);

-- Barbers: Must be visible to everyone
DROP POLICY IF EXISTS "barbers_select_policy" ON barbers;
CREATE POLICY "barbers_select_policy"
  ON barbers FOR SELECT TO public
  USING (is_active = true);

-- Bookings: Read-only for checking availability
DROP POLICY IF EXISTS "bookings_select_policy" ON bookings;
CREATE POLICY "bookings_select_policy"
  ON bookings FOR SELECT TO public
  USING (true);

-- Bookings: Insert for authenticated users
DROP POLICY IF EXISTS "bookings_insert_policy" ON bookings;
CREATE POLICY "bookings_insert_policy"
  ON bookings FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid() OR client_id IS NULL);

-- Bookings: Update own bookings
DROP POLICY IF EXISTS "bookings_update_policy" ON bookings;
CREATE POLICY "bookings_update_policy"
  ON bookings FOR UPDATE TO authenticated
  USING (client_id = auth.uid())
  WITH CHECK (client_id = auth.uid());
