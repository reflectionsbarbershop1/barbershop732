import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const url = new URL(req.url);
    const path = url.pathname.replace('/bookings-api', '');

    if (req.method === 'GET' && path === '/availability') {
      const barberId = url.searchParams.get('barber');
      const date = url.searchParams.get('date');

      if (!barberId || !date) {
        return new Response(
          JSON.stringify({ error: 'Missing barber or date parameter' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('start_time, end_time')
        .eq('barber_id', barberId)
        .eq('booking_date', date)
        .in('status', ['pending', 'confirmed']);

      if (error) throw error;

      const { data: barber } = await supabase
        .from('barbers')
        .select('start_time, end_time, days_off')
        .eq('id', barberId)
        .maybeSingle();

      return new Response(
        JSON.stringify({ bookings, barber }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'POST' && path === '/bookings') {
      const body = await req.json();
      const { barber_id, service_id, booking_date, start_time, client_name, client_phone, client_email } = body;

      if (!barber_id || !service_id || !booking_date || !start_time || !client_name) {
        return new Response(
          JSON.stringify({ error: 'Missing required fields' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const { data: service } = await supabase
        .from('services')
        .select('duration_minutes')
        .eq('id', service_id)
        .maybeSingle();

      if (!service) {
        return new Response(
          JSON.stringify({ error: 'Service not found' }),
          {
            status: 404,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const [hours, minutes] = start_time.split(':').map(Number);
      const endMinutes = hours * 60 + minutes + service.duration_minutes;
      const endHours = Math.floor(endMinutes / 60);
      const endMins = endMinutes % 60;
      const end_time = `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}:00`;

      const { data, error } = await supabase
        .from('bookings')
        .insert({
          barber_id,
          service_id,
          booking_date,
          start_time,
          end_time,
          client_name,
          client_phone,
          client_email,
          status: 'confirmed',
        })
        .select()
        .single();

      if (error) throw error;

      return new Response(
        JSON.stringify({ success: true, booking: data }),
        {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'GET' && path.startsWith('/bookings')) {
      const bookingId = path.split('/')[2];
      
      if (bookingId) {
        const { data, error } = await supabase
          .from('bookings')
          .select('*, barbers(display_name), services(name, price)')
          .eq('id', bookingId)
          .maybeSingle();

        if (error) throw error;

        return new Response(
          JSON.stringify(data),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      } else {
        const { data, error } = await supabase
          .from('bookings')
          .select('*, barbers(display_name), services(name, price)')
          .order('booking_date', { ascending: false })
          .limit(50);

        if (error) throw error;

        return new Response(
          JSON.stringify(data),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }
    }

    return new Response(
      JSON.stringify({ error: 'Not found' }),
      {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});