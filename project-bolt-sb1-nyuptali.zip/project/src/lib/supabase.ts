import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          phone: string | null;
          full_name: string;
          role: 'admin' | 'barber' | 'client';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          phone?: string | null;
          full_name: string;
          role?: 'admin' | 'barber' | 'client';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          phone?: string | null;
          full_name?: string;
          role?: 'admin' | 'barber' | 'client';
          created_at?: string;
          updated_at?: string;
        };
      };
      barbers: {
        Row: {
          id: string;
          user_id: string | null;
          display_name: string;
          bio: string;
          photo_url: string | null;
          instagram_handle: string | null;
          is_active: boolean;
          start_time: string;
          end_time: string;
          days_off: string[];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          display_name: string;
          bio?: string;
          photo_url?: string | null;
          instagram_handle?: string | null;
          is_active?: boolean;
          start_time?: string;
          end_time?: string;
          days_off?: string[];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          display_name?: string;
          bio?: string;
          photo_url?: string | null;
          instagram_handle?: string | null;
          is_active?: boolean;
          start_time?: string;
          end_time?: string;
          days_off?: string[];
          created_at?: string;
          updated_at?: string;
        };
      };
      services: {
        Row: {
          id: string;
          name: string;
          description: string;
          price: number;
          duration_minutes: number;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string;
          price: number;
          duration_minutes: number;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string;
          price?: number;
          duration_minutes?: number;
          is_active?: boolean;
          created_at?: string;
        };
      };
      bookings: {
        Row: {
          id: string;
          barber_id: string;
          client_id: string | null;
          service_id: string;
          booking_date: string;
          start_time: string;
          end_time: string;
          status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no_show';
          client_name: string;
          client_phone: string | null;
          client_email: string | null;
          notes: string;
          reminder_sent: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          barber_id: string;
          client_id?: string | null;
          service_id: string;
          booking_date: string;
          start_time: string;
          end_time: string;
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no_show';
          client_name: string;
          client_phone?: string | null;
          client_email?: string | null;
          notes?: string;
          reminder_sent?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          barber_id?: string;
          client_id?: string | null;
          service_id?: string;
          booking_date?: string;
          start_time?: string;
          end_time?: string;
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no_show';
          client_name?: string;
          client_phone?: string | null;
          client_email?: string | null;
          notes?: string;
          reminder_sent?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};
