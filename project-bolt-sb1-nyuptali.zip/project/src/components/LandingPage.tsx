import { Scissors, Clock, DollarSign, Instagram, Phone } from 'lucide-react';

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration_minutes: number;
}

interface LandingPageProps {
  services: Service[];
  onBookNow: () => void;
}

export default function LandingPage({ services, onBookNow }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <Scissors className="h-16 w-16 text-blue-400" strokeWidth={1.5} />
            </div>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight">
              Reflections Barbershop
            </h1>
            <p className="text-xl sm:text-2xl text-blue-400 mb-8 font-light">
              Book Your Fade at Reflections
            </p>
            <p className="text-lg text-slate-300 mb-12 max-w-2xl mx-auto">
              Premium barbershop services in New Jersey. Expert barbers, quality cuts, professional service.
            </p>
            <button
              onClick={onBookNow}
              className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-lg text-lg font-semibold transition-all transform hover:scale-105 shadow-xl hover:shadow-2xl"
            >
              Book Now
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold text-white text-center mb-12">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-slate-800 border border-slate-700 rounded-xl p-8 hover:border-blue-500 transition-all hover:shadow-xl hover:shadow-blue-500/20"
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-2xl font-bold text-white">{service.name}</h3>
                <div className="flex items-center text-blue-400 font-bold text-xl">
                  <DollarSign className="h-5 w-5" />
                  {service.price}
                </div>
              </div>
              <p className="text-slate-400 mb-4">{service.description}</p>
              <div className="flex items-center text-slate-400">
                <Clock className="h-4 w-4 mr-2" />
                <span>{service.duration_minutes} minutes</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-slate-800 border-t border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold text-white mb-2">Reflections Barbershop</h3>
              <p className="text-slate-400">reflectionsbarber.shop</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-6">
              <a
                href="tel:732"
                className="flex items-center text-slate-300 hover:text-blue-400 transition-colors"
              >
                <Phone className="h-5 w-5 mr-2" />
                <span className="font-semibold">732</span>
              </a>
              <a
                href="https://instagram.com/mario732barber"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-slate-300 hover:text-blue-400 transition-colors"
              >
                <Instagram className="h-5 w-5 mr-2" />
                <span className="font-semibold">@mario732barber</span>
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-700 text-center text-slate-500 text-sm">
            © {new Date().getFullYear()} Reflections Barbershop. All rights reserved.
          </div>
        </div>
      </div>
    </div>
  );
}
