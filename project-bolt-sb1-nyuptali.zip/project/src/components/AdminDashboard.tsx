import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Users, DollarSign, Calendar, TrendingUp, Plus, Edit2, Trash2 } from 'lucide-react';

interface Stats {
  totalBookings: number;
  todayBookings: number;
  totalRevenue: number;
  todayRevenue: number;
}

interface Barber {
  id: string;
  display_name: string;
  bio: string;
  photo_url: string | null;
  instagram_handle: string | null;
  is_active: boolean;
  user_id: string | null;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    todayBookings: 0,
    totalRevenue: 0,
    todayRevenue: 0,
  });
  const [barbers, setBarbers] = useState<Barber[]>([]);
  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [selectedTab, setSelectedTab] = useState<'overview' | 'barbers' | 'bookings' | 'import'>('overview');
  const [editingBarber, setEditingBarber] = useState<Barber | null>(null);
  const [csvContent, setCsvContent] = useState('');
  const [importType, setImportType] = useState<'bookings' | 'clients'>('bookings');

  useEffect(() => {
    fetchStats();
    fetchBarbers();
    fetchRecentBookings();
  }, []);

  const fetchStats = async () => {
    const today = new Date().toISOString().split('T')[0];

    const { data: allBookings } = await supabase
      .from('bookings')
      .select('id, booking_date, services(price)');

    const { data: todayBookings } = await supabase
      .from('bookings')
      .select('id, services(price)')
      .eq('booking_date', today);

    const totalRevenue = allBookings?.reduce((sum, b: any) => sum + (b.services?.price || 0), 0) || 0;
    const todayRev = todayBookings?.reduce((sum, b: any) => sum + (b.services?.price || 0), 0) || 0;

    setStats({
      totalBookings: allBookings?.length || 0,
      todayBookings: todayBookings?.length || 0,
      totalRevenue,
      todayRevenue: todayRev,
    });
  };

  const fetchBarbers = async () => {
    const { data } = await supabase
      .from('barbers')
      .select('*')
      .order('display_name');
    if (data) setBarbers(data);
  };

  const fetchRecentBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select(`
        *,
        barbers(display_name),
        services(name, price)
      `)
      .order('created_at', { ascending: false })
      .limit(10);

    if (data) setRecentBookings(data);
  };

  const toggleBarberStatus = async (barberId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('barbers')
      .update({ is_active: !currentStatus })
      .eq('id', barberId);

    if (!error) fetchBarbers();
  };

  const saveBarber = async () => {
    if (!editingBarber) return;

    if (editingBarber.id) {
      const { error } = await supabase
        .from('barbers')
        .update({
          display_name: editingBarber.display_name,
          bio: editingBarber.bio,
          photo_url: editingBarber.photo_url,
          instagram_handle: editingBarber.instagram_handle,
        })
        .eq('id', editingBarber.id);

      if (!error) {
        fetchBarbers();
        setEditingBarber(null);
      }
    } else {
      const { error } = await supabase
        .from('barbers')
        .insert({
          display_name: editingBarber.display_name,
          bio: editingBarber.bio,
          photo_url: editingBarber.photo_url,
          instagram_handle: editingBarber.instagram_handle,
          is_active: true,
        });

      if (!error) {
        fetchBarbers();
        setEditingBarber(null);
      }
    }
  };

  const deleteBarber = async (barberId: string) => {
    if (!confirm('Are you sure you want to delete this barber?')) return;

    const { error } = await supabase
      .from('barbers')
      .delete()
      .eq('id', barberId);

    if (!error) fetchBarbers();
  };

  const handleCSVImport = async () => {
    if (!csvContent.trim()) {
      alert('Please paste CSV content');
      return;
    }

    try {
      const lines = csvContent.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim());

      if (importType === 'bookings') {
        const bookingsToInsert = [];
        for (let i = 1; i < lines.length; i++) {
          const values = lines[i].split(',').map(v => v.trim());
          const booking: any = {};
          headers.forEach((header, index) => {
            booking[header] = values[index];
          });
          bookingsToInsert.push(booking);
        }

        const { error } = await supabase.from('bookings').insert(bookingsToInsert);
        if (error) throw error;

        alert(`Successfully imported ${bookingsToInsert.length} bookings`);
        setCsvContent('');
        fetchStats();
        fetchRecentBookings();
      }
    } catch (error) {
      console.error('Import error:', error);
      alert('Failed to import CSV. Please check the format and try again.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-slate-800 rounded-xl p-6 mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
          <p className="text-slate-400">Manage barbers, bookings, and view reports</p>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto">
          {(['overview', 'barbers', 'bookings', 'import'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`px-6 py-3 rounded-lg font-semibold capitalize transition-all ${
                selectedTab === tab
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {selectedTab === 'overview' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <div className="bg-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Total Bookings</p>
                    <p className="text-3xl font-bold text-white mt-1">{stats.totalBookings}</p>
                  </div>
                  <Calendar className="h-10 w-10 text-blue-400" />
                </div>
              </div>
              <div className="bg-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Today's Bookings</p>
                    <p className="text-3xl font-bold text-white mt-1">{stats.todayBookings}</p>
                  </div>
                  <TrendingUp className="h-10 w-10 text-green-400" />
                </div>
              </div>
              <div className="bg-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Total Revenue</p>
                    <p className="text-3xl font-bold text-white mt-1">${stats.totalRevenue}</p>
                  </div>
                  <DollarSign className="h-10 w-10 text-yellow-400" />
                </div>
              </div>
              <div className="bg-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Today's Revenue</p>
                    <p className="text-3xl font-bold text-white mt-1">${stats.todayRevenue}</p>
                  </div>
                  <DollarSign className="h-10 w-10 text-green-400" />
                </div>
              </div>
            </div>

            <div className="bg-slate-800 rounded-xl p-6">
              <h2 className="text-2xl font-bold text-white mb-6">Recent Bookings</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Client</th>
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Barber</th>
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Service</th>
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Date</th>
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Status</th>
                      <th className="text-left text-slate-400 font-semibold py-3 px-4">Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentBookings.map((booking) => (
                      <tr key={booking.id} className="border-b border-slate-700 hover:bg-slate-700">
                        <td className="py-3 px-4 text-white">{booking.client_name}</td>
                        <td className="py-3 px-4 text-slate-300">{booking.barbers?.display_name}</td>
                        <td className="py-3 px-4 text-slate-300">{booking.services?.name}</td>
                        <td className="py-3 px-4 text-slate-300">{booking.booking_date}</td>
                        <td className="py-3 px-4">
                          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500 text-white">
                            {booking.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-green-400 font-semibold">
                          ${booking.services?.price}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {selectedTab === 'barbers' && (
          <div className="bg-slate-800 rounded-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Manage Barbers</h2>
              <button
                onClick={() => setEditingBarber({ id: '', display_name: '', bio: '', photo_url: null, instagram_handle: '', is_active: true, user_id: null })}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Barber
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {barbers.map((barber) => (
                <div key={barber.id} className="bg-slate-700 rounded-lg overflow-hidden">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={barber.photo_url || 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=400'}
                      alt={barber.display_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-white">{barber.display_name}</h3>
                        <p className="text-slate-400 text-sm mt-1 line-clamp-2">{barber.bio}</p>
                        {barber.instagram_handle && (
                          <p className="text-blue-400 text-xs mt-1">{barber.instagram_handle}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingBarber(barber)}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => deleteBarber(barber.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <button
                      onClick={() => toggleBarberStatus(barber.id, barber.is_active)}
                      className={`w-full py-2 rounded-lg font-semibold text-sm ${
                        barber.is_active
                          ? 'bg-green-600 hover:bg-green-700 text-white'
                          : 'bg-slate-600 hover:bg-slate-500 text-slate-300'
                      }`}
                    >
                      {barber.is_active ? 'Active' : 'Inactive'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {editingBarber && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-slate-800 rounded-xl p-6 max-w-md w-full">
                  <h3 className="text-xl font-bold text-white mb-4">
                    {editingBarber.id ? 'Edit Barber' : 'Add Barber'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-slate-300 mb-2">Display Name</label>
                      <input
                        type="text"
                        value={editingBarber.display_name}
                        onChange={(e) => setEditingBarber({ ...editingBarber, display_name: e.target.value })}
                        className="w-full bg-slate-700 text-white rounded-lg px-4 py-2"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-2">Bio</label>
                      <textarea
                        value={editingBarber.bio}
                        onChange={(e) => setEditingBarber({ ...editingBarber, bio: e.target.value })}
                        className="w-full bg-slate-700 text-white rounded-lg px-4 py-2"
                        rows={3}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-2">Photo URL</label>
                      <input
                        type="url"
                        value={editingBarber.photo_url || ''}
                        onChange={(e) => setEditingBarber({ ...editingBarber, photo_url: e.target.value })}
                        className="w-full bg-slate-700 text-white rounded-lg px-4 py-2"
                        placeholder="https://example.com/photo.jpg"
                      />
                      <p className="text-slate-500 text-xs mt-1">Stock photos from Pexels or upload your own</p>
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-2">Instagram Handle</label>
                      <input
                        type="text"
                        value={editingBarber.instagram_handle || ''}
                        onChange={(e) => setEditingBarber({ ...editingBarber, instagram_handle: e.target.value })}
                        className="w-full bg-slate-700 text-white rounded-lg px-4 py-2"
                        placeholder="@username"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={saveBarber}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingBarber(null)}
                        className="flex-1 bg-slate-600 hover:bg-slate-500 text-white py-2 rounded-lg"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {selectedTab === 'bookings' && (
          <div className="bg-slate-800 rounded-xl p-6">
            <h2 className="text-2xl font-bold text-white mb-6">All Bookings</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Client</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Contact</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Barber</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Service</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Date</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Time</th>
                    <th className="text-left text-slate-400 font-semibold py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentBookings.map((booking) => (
                    <tr key={booking.id} className="border-b border-slate-700 hover:bg-slate-700">
                      <td className="py-3 px-4 text-white">{booking.client_name}</td>
                      <td className="py-3 px-4 text-slate-300 text-sm">
                        {booking.client_phone && <div>{booking.client_phone}</div>}
                        {booking.client_email && <div>{booking.client_email}</div>}
                      </td>
                      <td className="py-3 px-4 text-slate-300">{booking.barbers?.display_name}</td>
                      <td className="py-3 px-4 text-slate-300">{booking.services?.name}</td>
                      <td className="py-3 px-4 text-slate-300">{booking.booking_date}</td>
                      <td className="py-3 px-4 text-slate-300">{booking.start_time}</td>
                      <td className="py-3 px-4">
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500 text-white">
                          {booking.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {selectedTab === 'import' && (
          <div className="bg-slate-800 rounded-xl p-6">
            <h2 className="text-2xl font-bold text-white mb-6">Import Data from CSV</h2>
            <div className="mb-6">
              <label className="block text-slate-300 mb-2">Import Type</label>
              <select
                value={importType}
                onChange={(e) => setImportType(e.target.value as 'bookings' | 'clients')}
                className="bg-slate-700 text-white rounded-lg px-4 py-2"
              >
                <option value="bookings">Bookings</option>
                <option value="clients">Clients</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-slate-300 mb-2">
                Paste CSV Content (include headers)
              </label>
              <textarea
                value={csvContent}
                onChange={(e) => setCsvContent(e.target.value)}
                className="w-full bg-slate-700 text-white rounded-lg px-4 py-2 font-mono text-sm"
                rows={10}
                placeholder="barber_id,service_id,booking_date,start_time,end_time,client_name,client_phone,client_email,status"
              />
            </div>
            <button
              onClick={handleCSVImport}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold"
            >
              Import CSV
            </button>
            <div className="mt-6 bg-slate-700 rounded-lg p-4">
              <h3 className="text-white font-semibold mb-2">CSV Format Example:</h3>
              <pre className="text-slate-300 text-xs overflow-x-auto">
                {`barber_id,service_id,booking_date,start_time,end_time,client_name,client_phone,client_email,status
uuid-here,uuid-here,2024-01-15,10:00:00,10:30:00,John Doe,555-0100,john@email.com,confirmed`}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
