import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ChevronLeft, ChevronRight, X, Loader2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Barber {
  id: string;
  display_name: string;
  bio: string;
  photo_url: string | null;
  start_time: string;
  end_time: string;
  days_off: string[];
}

interface Service {
  id: string;
  name: string;
  price: number;
  duration_minutes: number;
  description?: string;
  is_active: boolean;
}

interface BookingCalendarProps {
  onClose: () => void;
}

export default function BookingCalendar({ onClose }: BookingCalendarProps) {
  const { user, profile } = useAuth();

  // Step management
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  // Selection state
  const [selectedService, setSelectedService] = useState('');
  const [selectedBarber, setSelectedBarber] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');

  // Data
  const [barbers, setBarbers] = useState<Barber[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Form data
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [bookingInProgress, setBookingInProgress] = useState(false);

  // Load barbers and services on mount
  useEffect(() => {
    console.log('Component mounted, loading data...');
    loadBarbers();
    loadServices();
  }, []);

  // Pre-fill user info
  useEffect(() => {
    if (profile) {
      setClientName(profile.full_name || '');
      setClientEmail(profile.email || '');
      setClientPhone(profile.phone || '');
    }
  }, [profile]);

  // Load available slots when barber and date are selected
  useEffect(() => {
    if (selectedBarber && selectedDate && selectedService) {
      console.log('Loading slots for:', { selectedBarber, selectedDate, selectedService });
      loadAvailableSlots();
    }
  }, [selectedBarber, selectedDate, selectedService]);

  const loadBarbers = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('barbers')
        .select('*')
        .eq('is_active', true)
        .order('display_name');

      if (error) throw error;

      console.log('Barbers loaded:', data?.length || 0);
      setBarbers(data || []);
    } catch (error) {
      console.error('Error loading barbers:', error);
    } finally {
      setTimeout(() => setIsLoading(false), 500);
    }
  };

  const loadServices = async () => {
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;

      console.log('Services loaded:', data?.length || 0);
      setServices(data || []);
    } catch (error) {
      console.error('Error loading services:', error);
    }
  };

  const loadAvailableSlots = async () => {
    if (!selectedBarber || !selectedDate || !selectedService) return;

    try {
      setIsLoading(true);

      const barber = barbers.find(b => b.id === selectedBarber);
      const service = services.find(s => s.id === selectedService);

      if (!barber || !service) return;

      // Check if barber is off today
      const dayName = selectedDate.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
      if (barber.days_off.includes(dayName)) {
        setAvailableSlots([]);
        setIsLoading(false);
        return;
      }

      // Get existing bookings for this barber on this date
      const dateStr = selectedDate.toISOString().split('T')[0];
      const { data: bookings } = await supabase
        .from('bookings')
        .select('start_time, end_time')
        .eq('barber_id', selectedBarber)
        .eq('booking_date', dateStr)
        .in('status', ['pending', 'confirmed']);

      // Generate time slots
      const slots: string[] = [];
      const [startHour, startMin] = barber.start_time.split(':').map(Number);
      const [endHour, endMin] = barber.end_time.split(':').map(Number);

      let currentTime = startHour * 60 + startMin;
      const endTime = endHour * 60 + endMin;

      while (currentTime + service.duration_minutes <= endTime) {
        const hours = Math.floor(currentTime / 60);
        const minutes = currentTime % 60;
        const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:00`;

        // Check if slot is available
        const endMinutes = currentTime + service.duration_minutes;
        const endHours = Math.floor(endMinutes / 60);
        const endMins = endMinutes % 60;
        const endTimeStr = `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}:00`;

        const isBooked = bookings?.some((booking: any) => {
          const bookingStart = booking.start_time;
          const bookingEnd = booking.end_time;
          return (timeStr >= bookingStart && timeStr < bookingEnd) ||
                 (endTimeStr > bookingStart && endTimeStr <= bookingEnd) ||
                 (timeStr <= bookingStart && endTimeStr >= bookingEnd);
        });

        if (!isBooked) {
          slots.push(timeStr);
        }

        currentTime += 15; // 15-minute increments
      }

      console.log('Available slots:', slots.length);
      setAvailableSlots(slots);
    } catch (error) {
      console.error('Error loading slots:', error);
      setAvailableSlots([]);
    } finally {
      setTimeout(() => setIsLoading(false), 500);
    }
  };

  const handleServiceSelect = (serviceId: string) => {
    console.log('Service selected:', serviceId);
    setSelectedService(serviceId);
    setTimeout(() => setCurrentStep(2), 300);
  };

  const handleBarberSelect = (barberId: string) => {
    console.log('Barber selected:', barberId);
    setSelectedBarber(barberId);
    setTimeout(() => setCurrentStep(3), 300);
  };

  const handleDateSelect = (date: Date) => {
    console.log('Date selected:', date);
    setSelectedDate(date);
    setTimeout(() => setCurrentStep(4), 300);
  };

  const handleTimeSelect = (time: string) => {
    console.log('Time selected:', time);
    setSelectedTime(time);
  };

  const handleConfirmBooking = async () => {
    // Validate all fields
    if (!selectedService || !selectedBarber || !selectedDate || !selectedTime) {
      alert('Please fill all fields: service, barber, date, and time');
      console.error('Missing fields:', { selectedService, selectedBarber, selectedDate, selectedTime });
      return;
    }

    if (!clientName || !clientEmail) {
      alert('Please enter your name and email');
      console.error('Missing client info:', { clientName, clientEmail });
      return;
    }

    try {
      setBookingInProgress(true);
      console.log('Creating booking with:', {
        service: selectedService,
        barber: selectedBarber,
        date: selectedDate,
        time: selectedTime,
        client: { name: clientName, email: clientEmail, phone: clientPhone }
      });

      const service = services.find(s => s.id === selectedService);
      if (!service) {
        console.error('Service not found:', selectedService);
        throw new Error('Service not found');
      }

      const [hours, minutes] = selectedTime.split(':').map(Number);
      const endMinutes = hours * 60 + minutes + service.duration_minutes;
      const endHours = Math.floor(endMinutes / 60);
      const endMins = endMinutes % 60;
      const endTime = `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}:00`;

      const bookingData = {
        barber_id: selectedBarber,
        client_id: user?.id || null,
        service_id: selectedService,
        booking_date: selectedDate.toISOString().split('T')[0],
        start_time: selectedTime,
        end_time: endTime,
        client_name: clientName,
        client_phone: clientPhone || '',
        client_email: clientEmail,
        status: 'confirmed',
      };

      console.log('Inserting booking:', bookingData);

      const { data, error } = await supabase.from('bookings').insert(bookingData).select();

      if (error) {
        console.error('Booking error:', error.message, error);
        throw error;
      }

      console.log('Booking created successfully:', data);

      const barber = barbers.find(b => b.id === selectedBarber);
      const formattedTime = formatTime(selectedTime);
      const formattedDate = selectedDate.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });

      alert(
        `✓ Booking Confirmed!\n\n` +
        `Service: ${service.name}\n` +
        `Barber: ${barber?.display_name}\n` +
        `Date: ${formattedDate}\n` +
        `Time: ${formattedTime}\n\n` +
        `📱 SMS confirmation sent to ${clientPhone || clientEmail}`
      );

      console.log('✓ Booking confirmed! Fake SMS sent.');
      onClose();
    } catch (error: any) {
      console.error('✗ Booking error:', error?.message || 'Unknown error', error);
      alert(`Failed to create booking: ${error?.message || 'Please try again'}`);
    } finally {
      setBookingInProgress(false);
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];

    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }

    return days;
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">Select a Service</h3>
        <p className="text-slate-400">Choose the service you'd like to book</p>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Loader2 className="h-12 w-12 text-blue-500 animate-spin mb-4" />
          <p className="text-slate-400">Loading services...</p>
        </div>
      ) : services.length === 0 ? (
        <div className="bg-slate-700 rounded-lg p-8 text-center">
          <p className="text-slate-300">No services available.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {services.map((service) => (
            <label
              key={service.id}
              className={`flex items-center space-x-4 p-5 rounded-lg border-2 cursor-pointer transition-all ${
                selectedService === service.id
                  ? 'border-blue-500 bg-slate-700'
                  : 'border-slate-600 bg-slate-800 hover:border-slate-500'
              }`}
            >
              <input
                type="radio"
                name="service"
                value={service.id}
                checked={selectedService === service.id}
                onChange={(e) => handleServiceSelect(e.target.value)}
                className="w-5 h-5 text-blue-600"
              />
              <div className="flex-1">
                <div className="text-white font-bold text-lg">{service.name}</div>
                <div className="text-slate-400 text-sm">
                  ${service.price} • {service.duration_minutes} minutes
                </div>
              </div>
            </label>
          ))}
        </div>
      )}
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">Select Your Barber</h3>
        <p className="text-slate-400">Choose your preferred barber from our team</p>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Loader2 className="h-12 w-12 text-blue-500 animate-spin mb-4" />
          <p className="text-slate-400">Loading barbers...</p>
        </div>
      ) : barbers.length === 0 ? (
        <div className="bg-slate-700 rounded-lg p-8 text-center">
          <p className="text-slate-300">No barbers available at the moment.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-h-[400px] overflow-y-auto">
          {barbers.map((barber) => (
            <button
              key={barber.id}
              onClick={() => handleBarberSelect(barber.id)}
              className={`rounded-lg overflow-hidden transition-all border-2 ${
                selectedBarber === barber.id
                  ? 'border-blue-500 ring-2 ring-blue-500'
                  : 'border-transparent hover:border-slate-500'
              }`}
            >
              <div className="aspect-square overflow-hidden bg-slate-700">
                <img
                  src={barber.photo_url || 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=400'}
                  alt={barber.display_name}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  loading="lazy"
                />
              </div>
              <div className="p-3 bg-slate-800">
                <div className="text-white font-semibold text-center">{barber.display_name}</div>
                <div className="text-slate-400 text-xs mt-1 text-center line-clamp-2">
                  {barber.bio}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      <button
        onClick={() => setCurrentStep(1)}
        className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
      >
        ← Back to Services
      </button>
    </div>
  );

  const renderStep3 = () => {
    const days = getDaysInMonth(currentMonth);
    const monthYear = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return (
      <div className="space-y-6">
        <div>
          <h3 className="text-2xl font-bold text-white mb-2">Select a Date</h3>
          <p className="text-slate-400">Choose when you'd like your appointment</p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
              className="text-white hover:text-blue-400 p-2"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <h3 className="text-lg font-semibold text-white">{monthYear}</h3>
            <button
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
              className="text-white hover:text-blue-400 p-2"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-2 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-slate-400 text-sm font-semibold py-2">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {days.map((day, index) => (
              <button
                key={index}
                disabled={!day || day < today}
                onClick={() => day && handleDateSelect(day)}
                className={`aspect-square rounded-lg flex items-center justify-center text-sm transition-all ${
                  !day
                    ? 'invisible'
                    : day < today
                    ? 'text-slate-600 cursor-not-allowed'
                    : selectedDate?.toDateString() === day.toDateString()
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-slate-700 text-white hover:bg-slate-600'
                }`}
              >
                {day?.getDate()}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => setCurrentStep(2)}
          className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
        >
          ← Back to Barber Selection
        </button>
      </div>
    );
  };

  const renderStep4 = () => {
    const service = services.find(s => s.id === selectedService);
    const barber = barbers.find(b => b.id === selectedBarber);

    return (
      <div className="space-y-6">
        <div>
          <h3 className="text-2xl font-bold text-white mb-2">Select a Time</h3>
          <p className="text-slate-400">
            {selectedDate?.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-12 w-12 text-blue-500 animate-spin mb-4" />
            <p className="text-slate-400">Loading available slots...</p>
          </div>
        ) : availableSlots.length === 0 ? (
          <div className="bg-slate-700 rounded-lg p-8 text-center">
            <p className="text-slate-300 mb-2">No available slots for this date.</p>
            <p className="text-slate-400 text-sm">Please try another date or choose a different barber.</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 md:grid-cols-4 gap-3 max-h-[300px] overflow-y-auto">
              {availableSlots.map((slot) => (
                <button
                  key={slot}
                  onClick={() => handleTimeSelect(slot)}
                  className={`py-3 rounded-lg font-semibold transition-all ${
                    selectedTime === slot
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-white hover:bg-slate-600'
                  }`}
                >
                  {formatTime(slot)}
                </button>
              ))}
            </div>

            {selectedTime && (
              <div className="bg-slate-700 rounded-lg p-6 space-y-4 border-2 border-blue-500">
                <h4 className="text-lg font-semibold text-white mb-4">Booking Summary</h4>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Service:</span>
                    <span className="text-white font-semibold">{service?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Barber:</span>
                    <span className="text-white font-semibold">{barber?.display_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Date:</span>
                    <span className="text-white font-semibold">
                      {selectedDate?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Time:</span>
                    <span className="text-white font-semibold">{formatTime(selectedTime)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-600 pt-2">
                    <span className="text-slate-400">Price:</span>
                    <span className="text-blue-400 font-bold text-lg">${service?.price}</span>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-600">
                  <h5 className="text-white font-semibold">Your Information</h5>

                  <div>
                    <label className="block text-slate-300 mb-1 text-sm">Name *</label>
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="w-full bg-slate-600 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="John Doe"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 text-sm">Email *</label>
                    <input
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      className="w-full bg-slate-600 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="john@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 text-sm">Phone (Optional)</label>
                    <input
                      type="tel"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      className="w-full bg-slate-600 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="555-1234"
                    />
                  </div>

                  <button
                    onClick={handleConfirmBooking}
                    disabled={bookingInProgress || !clientName || !clientEmail}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    {bookingInProgress ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" />
                        Booking...
                      </>
                    ) : (
                      '✓ Confirm Booking'
                    )}
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        <button
          onClick={() => {
            setCurrentStep(3);
            setSelectedTime('');
          }}
          className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
        >
          ← Back to Date Selection
        </button>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-slate-900 border-b border-slate-700 p-6 flex justify-between items-center z-10">
          <div>
            <h2 className="text-2xl font-bold text-white">Book Appointment</h2>
            <p className="text-slate-400 text-sm mt-1">Step {currentStep} of 4</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Progress Bar */}
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`flex-1 h-2 rounded transition-all ${
                  currentStep >= step ? 'bg-blue-600' : 'bg-slate-700'
                }`}
              />
            ))}
          </div>

          {/* Render current step */}
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
        </div>
      </div>
    </div>
  );
}
