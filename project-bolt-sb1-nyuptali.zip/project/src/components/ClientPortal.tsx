import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Clock, User, XCircle } from 'lucide-react';

interface Booking {
  id: string;
  booking_date: string;
  start_time: string;
  end_time: string;
  status: string;
  barbers: {
    display_name: string;
  };
  services: {
    name: string;
    price: number;
  };
}

export default function ClientPortal() {
  const { profile } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'past'>('upcoming');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      fetchBookings();
    }
  }, [profile, filter]);

  const fetchBookings = async () => {
    setLoading(true);
    let query = supabase
      .from('bookings')
      .select(`
        *,
        barbers (display_name),
        services (name, price)
      `)
      .eq('client_id', profile?.id)
      .order('booking_date', { ascending: false })
      .order('start_time', { ascending: false });

    const today = new Date().toISOString().split('T')[0];

    if (filter === 'upcoming') {
      query = query.gte('booking_date', today);
    } else if (filter === 'past') {
      query = query.lt('booking_date', today);
    }

    const { data } = await query;
    if (data) setBookings(data);
    setLoading(false);
  };

  const cancelBooking = async (bookingId: string) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;

    const { error } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', bookingId);

    if (!error) {
      fetchBookings();
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };

  const formatDate = (date: string) => {
    return new Date(date + 'T00:00:00').toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      case 'cancelled': return 'bg-red-500';
      case 'no_show': return 'bg-gray-500';
      default: return 'bg-yellow-500';
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-slate-800 rounded-xl p-6 mb-6">
          <div className="flex items-center gap-4 mb-4">
            <User className="h-12 w-12 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">{profile?.full_name}</h1>
              <p className="text-slate-400">{profile?.email}</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">My Appointments</h2>
            <div className="flex gap-2">
              {(['all', 'upcoming', 'past'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-2 rounded-lg font-semibold capitalize transition-all ${
                    filter === f
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12 text-slate-400">Loading...</div>
          ) : bookings.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">No appointments found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-slate-700 rounded-lg p-6 hover:bg-slate-600 transition-all"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${getStatusColor(booking.status)}`}>
                          {booking.status}
                        </span>
                        <span className="text-slate-400 text-sm">
                          {formatDate(booking.booking_date)}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="flex items-center gap-2 text-white">
                          <Clock className="h-5 w-5 text-blue-400" />
                          <span className="font-semibold">
                            {formatTime(booking.start_time)} - {formatTime(booking.end_time)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-white">
                          <User className="h-5 w-5 text-blue-400" />
                          <span>{booking.barbers?.display_name}</span>
                        </div>
                        <div className="text-slate-300">
                          {booking.services?.name}
                        </div>
                        <div className="text-green-400 font-semibold">
                          ${booking.services?.price}
                        </div>
                      </div>
                    </div>
                    {booking.status === 'pending' || booking.status === 'confirmed' ? (
                      <button
                        onClick={() => cancelBooking(booking.id)}
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all"
                      >
                        <XCircle className="h-4 w-4" />
                        Cancel
                      </button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
