import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Clock, User, CheckCircle, XCircle } from 'lucide-react';

interface Booking {
  id: string;
  booking_date: string;
  start_time: string;
  end_time: string;
  client_name: string;
  client_phone: string | null;
  client_email: string | null;
  status: string;
  notes: string;
  services: {
    name: string;
    price: number;
  };
}

export default function BarberDashboard() {
  const { profile } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [barber, setBarber] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      fetchBarberInfo();
    }
  }, [profile]);

  useEffect(() => {
    if (barber) {
      fetchBookings();
    }
  }, [barber, selectedDate]);

  const fetchBarberInfo = async () => {
    const { data } = await supabase
      .from('barbers')
      .select('*')
      .eq('user_id', profile?.id)
      .maybeSingle();

    if (data) setBarber(data);
  };

  const fetchBookings = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('bookings')
      .select(`
        *,
        services (
          name,
          price
        )
      `)
      .eq('barber_id', barber.id)
      .eq('booking_date', selectedDate)
      .order('start_time');

    if (data) setBookings(data);
    setLoading(false);
  };

  const updateBookingStatus = async (bookingId: string, status: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', bookingId);

    if (!error) {
      fetchBookings();
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      case 'cancelled': return 'bg-red-500';
      case 'no_show': return 'bg-gray-500';
      default: return 'bg-yellow-500';
    }
  };

  const todayRevenue = bookings
    .filter(b => b.status === 'completed')
    .reduce((sum, b) => sum + (b.services?.price || 0), 0);

  return (
    <div className="min-h-screen bg-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-slate-800 rounded-xl p-6 mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome, {barber?.display_name}
          </h1>
          <p className="text-slate-400">Manage your appointments and schedule</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Today's Bookings</p>
                <p className="text-3xl font-bold text-white mt-1">{bookings.length}</p>
              </div>
              <Calendar className="h-10 w-10 text-blue-400" />
            </div>
          </div>
          <div className="bg-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Completed</p>
                <p className="text-3xl font-bold text-white mt-1">
                  {bookings.filter(b => b.status === 'completed').length}
                </p>
              </div>
              <CheckCircle className="h-10 w-10 text-green-400" />
            </div>
          </div>
          <div className="bg-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Revenue</p>
                <p className="text-3xl font-bold text-white mt-1">${todayRevenue}</p>
              </div>
              <Clock className="h-10 w-10 text-yellow-400" />
            </div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">Appointments</h2>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-slate-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {loading ? (
            <div className="text-center py-12 text-slate-400">Loading...</div>
          ) : bookings.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              No appointments for this date
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-slate-700 rounded-lg p-6 hover:bg-slate-600 transition-all"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <User className="h-5 w-5 text-blue-400" />
                        <span className="text-white font-semibold text-lg">
                          {booking.client_name}
                        </span>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${getStatusColor(booking.status)}`}>
                          {booking.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-slate-300">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          {formatTime(booking.start_time)} - {formatTime(booking.end_time)}
                        </div>
                        <div>{booking.services?.name} - ${booking.services?.price}</div>
                        {booking.client_phone && <div>📱 {booking.client_phone}</div>}
                        {booking.client_email && <div>✉️ {booking.client_email}</div>}
                      </div>
                      {booking.notes && (
                        <div className="mt-2 text-sm text-slate-400 italic">
                          Note: {booking.notes}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {booking.status === 'pending' && (
                        <>
                          <button
                            onClick={() => updateBookingStatus(booking.id, 'confirmed')}
                            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all"
                          >
                            <CheckCircle className="h-4 w-4" />
                            Confirm
                          </button>
                          <button
                            onClick={() => updateBookingStatus(booking.id, 'cancelled')}
                            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all"
                          >
                            <XCircle className="h-4 w-4" />
                            Cancel
                          </button>
                        </>
                      )}
                      {booking.status === 'confirmed' && (
                        <button
                          onClick={() => updateBookingStatus(booking.id, 'completed')}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all"
                        >
                          Mark Complete
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
