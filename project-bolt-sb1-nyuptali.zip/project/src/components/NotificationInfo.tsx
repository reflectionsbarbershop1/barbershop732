export default function NotificationInfo() {
  return (
    <div className="bg-slate-800 rounded-xl p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-white mb-4">SMS Notifications Setup</h2>
      <div className="space-y-4 text-slate-300">
        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-white mb-2">Twilio Integration</h3>
          <p className="mb-2">
            To enable SMS confirmations and reminders, you need to integrate Twilio:
          </p>
          <ol className="list-decimal list-inside space-y-2 ml-4">
            <li>Create a Twilio account at twilio.com</li>
            <li>Get your Account SID and Auth Token from the Twilio Console</li>
            <li>Purchase a Twilio phone number</li>
            <li>Create a Supabase Edge Function for sending SMS</li>
            <li>Set up a scheduled function to send reminders 24 hours before appointments</li>
          </ol>
        </div>

        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-white mb-2">Example Message Templates</h3>
          <div className="space-y-2 text-sm font-mono">
            <div className="bg-slate-800 p-3 rounded">
              <p className="text-green-400">Confirmation:</p>
              <p className="text-slate-300">
                "Your appointment at Reflections Barbershop is confirmed! [Service] with [Barber] on [Date] at [Time]. See you soon!"
              </p>
            </div>
            <div className="bg-slate-800 p-3 rounded">
              <p className="text-yellow-400">Reminder:</p>
              <p className="text-slate-300">
                "Reminder: Your [Service] appointment with [Barber] is tomorrow at [Time]. Reply CANCEL to cancel."
              </p>
            </div>
          </div>
        </div>

        <div className="bg-blue-900 bg-opacity-30 border border-blue-500 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-blue-400 mb-2">Current Status</h3>
          <p className="text-slate-300">
            SMS notifications are ready to be integrated. The booking system tracks phone numbers
            and has a reminder_sent flag. You can implement the Twilio integration as a separate
            Edge Function that runs on a schedule to check for upcoming appointments.
          </p>
        </div>
      </div>
    </div>
  );
}
