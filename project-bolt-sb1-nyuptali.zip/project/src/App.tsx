import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LandingPage from './components/LandingPage';
import BookingCalendar from './components/BookingCalendar';
import BarberDashboard from './components/BarberDashboard';
import AdminDashboard from './components/AdminDashboard';
import ClientPortal from './components/ClientPortal';
import AuthModal from './components/AuthModal';
import { supabase } from './lib/supabase';
import { LogOut, Calendar, User, LayoutDashboard } from 'lucide-react';

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration_minutes: number;
}

function AppContent() {
  const { user, profile, signOut, loading } = useAuth();
  const [services, setServices] = useState<Service[]>([]);
  const [showBooking, setShowBooking] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard' | 'portal'>('landing');

  useEffect(() => {
    console.log('App mounted');
    fetchServices();
  }, []);

  useEffect(() => {
    if (profile) {
      if (profile.role === 'admin') {
        setCurrentView('dashboard');
      } else if (profile.role === 'barber') {
        setCurrentView('dashboard');
      } else {
        setCurrentView('landing');
      }
    } else {
      setCurrentView('landing');
    }
  }, [profile]);

  const fetchServices = async () => {
    try {
      console.log('Fetching services...');
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('is_active', true)
        .order('price');

      if (error) {
        console.error('Error fetching services:', error);
      } else {
        console.log('Services fetched:', data?.length || 0);
        if (data) setServices(data);
      }
    } catch (error) {
      console.error('Exception fetching services:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setCurrentView('landing');
  };

  console.log('Render state:', { loading, user: !!user, profile: !!profile, currentView });

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-white text-xl mb-2">Loading...</div>
          <div className="text-slate-400 text-sm">Initializing application</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      {user && (
        <nav className="bg-slate-800 border-b border-slate-700 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setCurrentView('landing')}
                  className="text-white font-bold text-xl hover:text-blue-400 transition-colors"
                >
                  Reflections
                </button>
                {profile?.role === 'client' && (
                  <>
                    <button
                      onClick={() => setShowBooking(true)}
                      className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
                    >
                      <Calendar className="h-5 w-5" />
                      <span>Book</span>
                    </button>
                    <button
                      onClick={() => setCurrentView('portal')}
                      className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
                    >
                      <User className="h-5 w-5" />
                      <span>My Appointments</span>
                    </button>
                  </>
                )}
                {(profile?.role === 'barber' || profile?.role === 'admin') && (
                  <button
                    onClick={() => setCurrentView('dashboard')}
                    className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
                  >
                    <LayoutDashboard className="h-5 w-5" />
                    <span>Dashboard</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-4">
                <span className="text-slate-300">{profile?.full_name}</span>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        </nav>
      )}

      {currentView === 'landing' && (
        <LandingPage
          services={services}
          onBookNow={() => {
            if (user) {
              setShowBooking(true);
            } else {
              setAuthMode('signup');
              setShowAuth(true);
            }
          }}
        />
      )}

      {currentView === 'dashboard' && profile?.role === 'admin' && <AdminDashboard />}
      {currentView === 'dashboard' && profile?.role === 'barber' && <BarberDashboard />}
      {currentView === 'portal' && profile?.role === 'client' && <ClientPortal />}

      {!user && currentView === 'landing' && (
        <div className="fixed bottom-8 right-8 flex gap-4">
          <button
            onClick={() => {
              setAuthMode('signin');
              setShowAuth(true);
            }}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-lg font-semibold shadow-xl transition-all"
          >
            Sign In
          </button>
          <button
            onClick={() => {
              setAuthMode('signup');
              setShowAuth(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold shadow-xl transition-all"
          >
            Sign Up
          </button>
        </div>
      )}

      {showBooking && <BookingCalendar onClose={() => setShowBooking(false)} />}
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} mode={authMode} />}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
